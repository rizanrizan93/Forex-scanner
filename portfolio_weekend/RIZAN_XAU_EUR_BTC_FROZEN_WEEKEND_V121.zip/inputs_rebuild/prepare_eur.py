"""Reconstruct the archived EUR OHLC minute stream; no missing-minute filling."""
import argparse, hashlib, io, json, zipfile
from pathlib import Path
import pandas as pd

parser = argparse.ArgumentParser()
parser.add_argument('eur_2016_2026_replay_zip')
parser.add_argument('output_csv')
args = parser.parse_args()
archive = zipfile.ZipFile(args.eur_2016_2026_replay_zip)
manifest = json.loads(archive.read('raw_original/manifest.json'))

def read(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        name = next(n for n in z.namelist() if n.endswith('.csv'))
        frame = pd.read_csv(z.open(name),sep=';',header=None,names=['timestamp','open','high','low','close','volume'])
    frame.timestamp = pd.to_datetime(frame.timestamp,format='%Y%m%d %H%M%S',utc=True)+pd.Timedelta(hours=5)
    return frame[['timestamp','open','high','low','close']]

parts=[]
for year in range(2016,2026):
    raw=archive.read(f'raw_original/EURUSD_M1_{year}.zip')
    expected=next(m for m in manifest if m['year']==year)
    assert hashlib.sha256(raw).hexdigest()==expected['sha256']
    frame=read(raw).drop_duplicates()
    assert not frame.timestamp.duplicated().any()
    assert len(frame)==expected['rows']
    parts.append(frame)
old=pd.concat(parts,ignore_index=True).sort_values('timestamp')
assert len(old)==3670894 and not old.timestamp.duplicated().any()
new=pd.concat([read(archive.read(name)) for name in sorted(archive.namelist()) if name.startswith('raw/histdata_eurusd_') and name.endswith('.zip')],ignore_index=True)
new=new.groupby('timestamp',as_index=False,sort=True).agg({'open':'first','high':'max','low':'min','close':'last'})
assert new.timestamp.min()>old.timestamp.max()
full=pd.concat([old,new],ignore_index=True)
assert len(full)==3957219 and full.timestamp.max()==pd.Timestamp('2026-10-09T21:58:00Z')
full.timestamp=full.timestamp.dt.strftime('%Y-%m-%dT%H:%M:%SZ')
full.to_csv(args.output_csv,index=False)
digest=hashlib.sha256(Path(args.output_csv).read_bytes()).hexdigest()
assert digest=='c907028058581ac3346770374ef15391239a8b46870740556e320409fa223bdb'
print('EUR_COMPLETE',len(full),digest)
