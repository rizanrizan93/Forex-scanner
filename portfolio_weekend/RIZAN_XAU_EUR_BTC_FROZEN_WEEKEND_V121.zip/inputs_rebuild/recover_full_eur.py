from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;out=r/'eur_2012_2026_recovered.csv'
with out.open('wb') as f,(r/'inputs/eur_2012_2026.csv').open('rb') as old:
 f.write(next(old))
 for line in old:
  if line[:4]>=b'2016':break
  f.write(line)
 with (r/'eur_2016_2026_recovered.csv').open('rb') as suffix:
  next(suffix)
  for line in suffix:f.write(line[:10]+b' '+line[11:19]+b'+00:00'+line[20:])
sha=hashlib.file_digest(out.open('rb'),'sha256').hexdigest();print(sha,flush=True)
assert sha=='3c74ac5ccaeeac64f44693bc6bd4406e9225a9ef61dbb5f80756530f050506ec'
