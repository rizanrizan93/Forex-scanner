# RIZAN XAU–EUR–BTC Frozen Weekend V1.2.1

**Source dibekukan dan pengaman akhir pekan lulus. Namun versi baru tidak memenuhi batas floating DD 56% pada dua jalur replay ini.** Belum dipasang ke live.

Modal awal $100 tanpa top-up. Periode 1 Januari 2019 sampai bar terakhir 9 Oktober 2026 21:58 UTC.

| Jalur | Saldo akhir USD | Floating DD model | Balance DD | PF | Basket XAU/EUR/BTC | BTC BUY/SELL |
|---|---:|---:|---:|---:|---:|---:|
| WEEKEND_PATH_A | 14,168,707.28 | 62.9488% | 49.6242% | 2.44654 | 287/178/96 | 41/55 |
| WEEKEND_PATH_B | 18,043,274.23 | 63.7768% | 51.6103% | 2.39867 | 291/179/95 | 40/55 |

Hasil lama $24,54–24,80 juta / DD 52,47–54,48% memakai BTC tujuh hari dan bukan hasil rilis ini. Kalender baru, penghapusan bar saat pasar tutup, dan pemotongan hold mengubah sinyal, transaksi, serta compounding. Tidak ada optimasi ulang atau penurunan risiko diam-diam untuk memulihkan DD 56%.

## Konfigurasi yang dibekukan

- BTC BUY profil 7844: H4 displacement_follow; body >1,4 ATR dan close >high sebelumnya; H4 bullish (close >EMA80 dan EMA20 >EMA80); sesi 00–08 UTC; SL 2 ATR, TP 12R, hold 128 jam, risk 23%, margin 95%.
- BTC SELL profil 2269: H1 compression_break; range empat bar <0,7 ATR dan close <low 16 bar −0,1 ATR; H4 bearish; body ≤2,5 ATR, RSI ≥25, rasio ATR 20 bar 0,6–1,8. SL 1,5 ATR, TP 2R, hold delapan jam, risk 18%, margin 30%.
- Satu basket BTC, tanpa layering/BE/trailing. Sinyal closed, entry berikutnya, chase ≤0,5 ATR; min 0,01 BTC, max 100 BTC, step dan limit broker dihormati.
- Risiko portofolio 20,75% dikunci, cap margin entry 50%. Model BTC 10× dan XAU/EUR 200× dipertahankan. Ini bukan hard stop drawdown 56%.
- Delapan file strategi XAU/EUR identik dengan baseline Settlement 1.1.1. Perubahan host terbatas pada penguncian risk cap, identitas versi/checkpoint, dan prioritas pengaman BTC sebelum kerja entry/bridge.

## Penutupan Jumat dan recovery

- Native membaca Symbol.MarketHours.IsOpened(DateTime) di UTC. Jadwal sesi terakhir Senin–Jumat dihitung dan disegarkan setiap lima menit. Jika hari libur tercermin di API, sesi terakhir bisa maju ke Kamis.
- Blokir entry BTC 60 menit sebelum penutupan; mulai flatten 30 menit sebelumnya. Hold efektif adalah nilai terkecil antara hold asli dan cutoff mingguan. Sabtu/Minggu UTC tidak entry. Sinyal Jumat tidak diulang pada Senin.
- Pengaman dipanggil lewat timer satu detik dan tick; timer host mendahulukannya sebelum kerja entry/bridge. Tidak bergantung pada tick BTC baru.
- ExitPending disimpan sebelum request. Close yang ditolak tidak dianggap berhasil; retry satu detik, termasuk setelah restart. Pengaman hanya menutup posisi BTC milik cBot. Posisi XAU/EUR/manual tidak ditutup. Mode Kirim order OFF juga memblokir close.
- Runtime harus aktif, Kirim order ON, dan broker terhubung. Jika offline, pasar sudah tutup, atau close terus ditolak, fill tidak dapat dijamin. Log EXIT_WAIT/CLOSE_RETRY dan intent dipertahankan; penutupan dicoba pada kesempatan pertama ketika pasar terbuka. Server-side SL/TP tetap ada.
- Contoh: Jumat 22 UTC = Sabtu 05 WIB; flatten dimulai Sabtu 04.30 WIB. Ini contoh konversi, bukan jam broker yang di-hardcode dalam cBot.

## Audit

Build resmi cTrader.Automate 1.0.21, reference .NET 6.0.36, SDK 8.0.426 berhasil. Sebanyak 1.326 pemeriksaan lulus: settlement 171, portofolio 827, timing 121, BTC 182, weekend 25. Native compiler akhir tanpa error/warning. Uji weekend mencakup close 21/22 UTC, batas entry/flat, libur Jumat, jadwal tidak tersedia, reject/retry, restart, pasar tutup, mode OFF, kepemilikan simbol, dan sinyal Senin baru.

EntryTime dan ClosingTime diperiksa secara independen untuk 191 posisi BTC (A 96 / B 95): nol entry akhir pekan, nol posisi melewati penutupan Jumat, dan nol pelanggaran buffer flat dalam toleransi lima detik. Kedua replay mencatat ErrorCount 0, tanpa quarantine/accounting block, tanpa posisi akhir atau close paksa khusus pada akhir periode.

Identitas gross PnL − komisi − funding/swap = net PnL, saldo = $100 + net, balance DD, dan PF direkonsiliasi ulang. Bukti ada di WEEKEND_AND_CASH_AUDIT.json. Ledger seluruh fill, kontribusi BUY/SELL, laporan bulanan/tahunan dan grafik disertakan.

## Batas hasil

**Kalender replay diasumsikan Senin 00 UTC–Jumat 22 UTC. Histori jadwal broker dan DST belum disertifikasi.** Native memakai jadwal API broker aktual. Bar BTC di luar sesi asumsi dikeluarkan dari indikator; tidak ada pengisian bar yang hilang dengan harga buatan.

Replay memakai dua jalur intramenit OHLC independen posisi dan broker tiruan, dengan ACK dua detik serta delay broker dua detik. Ini bukan rekaman tick broker, bukan FULL_PARITY, dan bukan bound konservatif semua urutan M1. Macro XAU masih rekonstruksi dan belum memiliki vintage point-in-time tersertifikasi. Biaya, swap dan leverage tetap asumsi model; stress biaya portofolio versi ini belum dijalankan.

Grafik memakai snapshot per jam; DD tabel berasal dari observasi event model. Hasil optimasi historis bukan bukti performa masa depan.

## Sumber

Native source commit: `1d6ad83f285f293b103342073b637fa16e597fb9`. Branch: `release/xau-eur-btc-frozen-weekend-v1.2.1`. Build awal: https://github.com/rizanrizan93/Forex-scanner/actions/runs/39371048685 .

Input SHA256: BTC `c217e367a22cab5f157d6d8a38828b9ada249f5a2d0657f20d204fee881c9504`; XAU `3fda8011082e2691b6ebe1a8a4da5fff8e4bf0fc07baf57506b7894d95fc1808`; EUR `3c74ac5ccaeeac64f44693bc6bd4406e9225a9ef61dbb5f80756530f050506ec`.

File .algo default Kirim order OFF. Tidak ada deployment live. Jangan jalankan versi lama dan baru bersamaan pada akun yang sama.
