"""Read-only streaming audit. No sorting, interpolation, or synthetic quotes."""
from pathlib import Path
import argparse,csv,hashlib,json,subprocess,os
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

p=argparse.ArgumentParser();p.add_argument('--target',required=True);p.add_argument('--key',required=True);p.add_argument('--hosts',required=True);p.add_argument('--out',required=True);a=p.parse_args()
out=Path(a.out);out.mkdir(parents=True,exist_ok=True);tmp=out/'incoming';tmp.mkdir(exist_ok=True)
opts=['-i',a.key,'-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+a.hosts,'-o','ConnectTimeout=30']
remote='/home/Rizanrizan/rizan-ticks'
def copy(rel,dest):subprocess.run(['scp',*opts,a.target+':'+remote+'/'+rel,str(dest)],check=True,stdout=subprocess.DEVNULL)
copy('.jobs/manifest_sha256.csv',out/'archive_manifest.csv');copy('.jobs/archive_status.json',out/'archive_status.json')
manifest={r['filename']:r for r in csv.DictReader((out/'archive_manifest.csv').open())}
months=[f'{y}-{m:02}' for y in range(2019,2027) for m in range(1,13) if (y,m)<=(2026,3)]
reports=[];allgaps=[];last={};m1handles={s:(out/(s+'_m1.csv')).open('w') for s in ['XAUUSD','EURUSD']}
for f in m1handles.values():f.write('timestamp,open,high,low,close,spread,roll,buy_ok,sell_ok\n')
for ym in months:
 for sym in ['XAUUSD','EURUSD']:
  name=f'{sym}_{ym}.parquet';dest=tmp/name;copy(f'{sym}/{ym[:4]}/{name}',dest)
  sha=hashlib.file_digest(dest.open('rb'),'sha256').hexdigest();pf=pq.ParquetFile(dest)
  point=int((pf.metadata.metadata or {}).get(b'point',b'0'));assert point==({'XAUUSD':1000,'EURUSD':100000}[sym]),(name,point)
  expected=manifest.get(name,{}).get('sha256');assert expected and sha==expected,('SHA_MISMATCH',name)
  n=bad=dups=back=nonpositive=badvol=0;first=None;prev=last.get(sym);pieces=[];spreads=[];sessions={};days=set();hours=set();gaps=[]
  for batch in pf.iter_batches(batch_size=131072):
   d=batch.to_pandas();t=pd.to_datetime(d.timestamp,utc=True).astype("datetime64[ns, UTC]");ns=t.astype('int64').to_numpy();bid=d.bid.to_numpy(dtype=float)/point;ask=d.ask.to_numpy(dtype=float)/point;sp=ask-bid
   assert np.isfinite(bid).all() and np.isfinite(ask).all(),('NONFINITE',name)
   n+=len(d);bad+=int((sp<0).sum());nonpositive+=int(((bid<=0)|(ask<=0)).sum());first=int(ns[0]) if first is None else first
   dt=np.diff(np.r_[prev,ns] if prev is not None else ns);dups+=int((dt==0).sum());back+=int((dt<0).sum())
   arr=np.r_[prev,ns] if prev is not None else ns
   for i in np.flatnonzero(dt>300_000_000_000):
    left=pd.Timestamp(int(arr[i]),unit='ns',tz='UTC');right=pd.Timestamp(int(arr[i+1]),unit='ns',tz='UTC')
    ny1=left.tz_convert('America/New_York');ny2=right.tz_convert('America/New_York')
    weekend=(ny1.dayofweek==4 and ny1.hour>=16 and ny2.dayofweek in [6,0]) or (right-left).total_seconds()>36*3600
    maintenance=sym=='XAUUSD' and ny1.hour in [16,17] and ny2.hour in [17,18] and (right-left).total_seconds()<3*3600
    gaps.append({'symbol':sym,'from':str(left),'to':str(right),'seconds':(right-left).total_seconds(),'classification':'weekend_or_holiday_candidate' if weekend else 'gold_daily_maintenance_candidate' if maintenance else 'unexplained_review_required'})
   prev=int(ns[-1]);days.update(t.dt.strftime('%Y-%m-%d').unique());hours.update(t.dt.strftime('%Y-%m-%dT%H').unique())
   for v in ['bid_volume','ask_volume']:
    if v not in d:raise RuntimeError('MISSING_VOLUME '+name)
    va=d[v].to_numpy(dtype=float);badvol+=int(((va<0)|~np.isfinite(va)).sum())
   q=pd.DataFrame({'t':t,'bid':bid,'spread':sp});g=q.set_index('t').resample('1min').agg({'bid':['first','max','min','last'],'spread':['mean']}).dropna();g.columns=['open','high','low','close','spread'];pieces.append(g)
   spreads.append(sp)
   wib=(t.dt.hour.to_numpy()+7)%24
   for label,mask in [('Asia',(wib>=6)&(wib<14)),('London',(wib>=14)&(wib<19)),('NewYork',(wib>=19)|(wib<1)),('Rollover',(wib>=1)&(wib<6))]:sessions.setdefault(label,[]).append(sp[mask])
  last[sym]=prev
  assert n==pf.metadata.num_rows and not (bad or back or nonpositive or badvol),(name,bad,back,nonpositive,badvol)
  sp=np.concatenate(spreads)
  stats=lambda z:{'n':len(z),'mean':float(np.mean(z)),'p50':float(np.quantile(z,.5)),'p95':float(np.quantile(z,.95)),'p99':float(np.quantile(z,.99)),'max':float(np.max(z))} if len(z) else None
  rep={'file':name,'sha256':sha,'manifest_match':True,'point':point,'ticks':n,'first_utc':str(pd.Timestamp(first,unit='ns',tz='UTC')),'last_utc':str(pd.Timestamp(prev,unit='ns',tz='UTC')),'duplicate_timestamps':dups,'backward_timestamps':back,'invalid_bid_ask':bad,'invalid_volume':badvol,'trading_days':len(days),'trading_hours':len(hours),'spread':stats(sp),'spread_sessions_wib':{k:stats(np.concatenate(v)) for k,v in sessions.items()},'gaps_gt_5m':len(gaps),'unexplained_gaps':sum(x['classification']=='unexplained_review_required' for x in gaps)}
  reports.append(rep);allgaps.extend(gaps)
  g=pd.concat(pieces).groupby(level=0).agg({'open':'first','high':'max','low':'min','close':'last','spread':'mean'})
  for row in g.itertuples():m1handles[sym].write(f'{row.Index.isoformat()},{row.open:.10f},{row.high:.10f},{row.low:.10f},{row.close:.10f},{row.spread:.10f},0,0,0\n')
  m1handles[sym].flush();dest.unlink()
  (out/'data_quality.json').write_text(json.dumps({'status':'AUDIT_RUNNING','processed_files':len(reports),'files':reports},indent=2))
  print('AUDIT',name,n,'gaps',rep['unexplained_gaps'],flush=True)
for f in m1handles.values():f.close()
(out/'gaps.json').write_text(json.dumps(allgaps,indent=2))
(out/'data_quality.json').write_text(json.dumps({'status':'SCANNED_ALL_174_FILES_REVIEW_GAPS','expected_files':174,'processed_files':len(reports),'total_ticks':sum(x['ticks'] for x in reports),'duplicates_are_retained':True,'no_interpolation':True,'gap_calendar_certified':False,'files':reports},indent=2))
