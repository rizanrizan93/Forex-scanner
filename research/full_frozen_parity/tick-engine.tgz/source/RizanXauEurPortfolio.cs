using cAlgo.API;
namespace cAlgo.Robots;
[Robot(TimeZone=TimeZones.UTC,AccessRights=AccessRights.None)]
public sealed class RizanXauEurPortfolio : Rizan.Portfolio.RizanPortfolio {}
