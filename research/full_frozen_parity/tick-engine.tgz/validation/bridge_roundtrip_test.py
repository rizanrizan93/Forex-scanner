import json,sys,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'bridge_reference'))
from server import Store,CONTRACTS
with tempfile.TemporaryDirectory() as d:
 s=Store(Path(d)/'state.sqlite');key='RZXRC1:1237903:XAUUSD';s.acquire(key,'fixture')
 state={'Schema':1,'ContractHash':CONTRACTS['RZXRC1']['hash'],'AccountNumber':1237903,'Symbol':'XAUUSD','Revision':1,'ExecutionModel':CONTRACTS['RZXRC1']['execution_model'],'PendingChildren':1,'RejectedFills':[{'PositionId':2,'Label':'RZXRC1|637134768000000000|1|2|1','Volume':1}]}
 v=s.save(key,'fixture',0,1,state);assert s.acquire(key,'fixture')==(v,state)
 s.db.close();s=Store(Path(d)/'state.sqlite');assert s.acquire(key,'fixture')==(v,state)
 print(json.dumps({'Pass':True,'Checks':2,'RemoteVPS':False}))
