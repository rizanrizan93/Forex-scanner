"""Compile and run regression suites with a supplied official .NET 8 SDK."""
from pathlib import Path
import argparse,json,subprocess,shutil
p=argparse.ArgumentParser();p.add_argument('--sdk',type=Path,required=True);a=p.parse_args()
r=Path(__file__).resolve().parent;sdk=a.sdk.resolve();refs=next((sdk/'packs/Microsoft.NETCore.App.Ref').glob('*/ref/net8.0'));csc=next((sdk/'sdk').glob('*/Roslyn/bincore/csc.dll'))
for name in ['SettlementTests','PortfolioTests','TimingTests']:
 o=r/'validation'/name
 if name=='SettlementTests':shutil.copy(r/'tests/SettlementTests.cs',o/(name+'.cs'))
 args=['-nologo','-target:exe','-langversion:latest','-nullable:enable','-define:REPLAY','-out:'+str(o/(name+'.dll'))]+['-r:'+str(p) for p in refs.glob('*.dll')]+[str(p) for p in (r/'source').rglob('*.cs')]+[str(p) for p in o.glob('*.cs')]
 rsp=o/'build.rsp';rsp.write_text('\n'.join(args))
 with (o/'build.log').open('w') as f:subprocess.run([str(sdk/'dotnet'),str(csc),'@'+str(rsp)],stdout=f,stderr=f,check=True)
 (o/(name+'.runtimeconfig.json')).write_text(json.dumps({'runtimeOptions':{'tfm':'net8.0','framework':{'name':'Microsoft.NETCore.App','version':'8.0.32'}}}))
 with (o/'result.json').open('w') as f,(o/'events.log').open('w') as e:subprocess.run([str(sdk/'dotnet'),str(o/(name+'.dll'))],stdout=f,stderr=e,check=True)
 print(name,(o/'result.json').read_text())
