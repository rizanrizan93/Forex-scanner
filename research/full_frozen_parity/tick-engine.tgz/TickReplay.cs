using System.Globalization;
using System.Reflection;
using System.Text.Json;
using System.IO.Compression;
using cAlgo.API;
using Rizan.Portfolio;
using X=Rizan.Portfolio.Xau;
using E=Rizan.Portfolio.Eur;

var dir=args[0];var resultDir=args[1];Directory.CreateDirectory(resultDir);
var xd=Data.Load(Path.Combine(dir,"XAUUSD_m1.csv"),true,2026);
var ed=Data.Load(Path.Combine(dir,"EURUSD_m1.csv"),false,2026);
var xt=Data.XauTape(xd);GC.Collect();var et=Data.EurTape(ed);GC.Collect();
var gates=Gates.Read(Path.Combine(args[2],"archived_macro_flags.json.gz"));
var configs=new[]{new Config("A_IDEAL_ARCHIVED_FLAGS",0,0,1,true,true,true),new Config("B_MODEL_2S_ARCHIVED_FLAGS",2,2,1,true,true,true),new Config("C_COST1_5_ARCHIVED_FLAGS",2,2,1.5,true,true,true),new Config("C_COST2_ARCHIVED_FLAGS",2,2,2,true,true,true),new Config("D_5S_ARCHIVED_FLAGS",5,5,1,true,true,true),new Config("D_10S_ARCHIVED_FLAGS",10,10,1,true,true,true),new Config("E_XAU_ONLY_ARCHIVED_FLAGS",2,2,1,true,false,true),new Config("STRICT_MISSING_MACRO_XAU_BLOCKED",2,2,1,true,true,false)};
var sims=configs.Select(c=>new TickSimulation(c,xd,ed,xt,et,gates)).ToArray();
Console.WriteLine("READY_FOR_MONTHS");Console.Out.Flush();
string? line;while((line=Console.ReadLine())!=null){if(line=="DONE")break;var parts=line.Split('|');var from=DateTime.Parse(parts[0]+"-01T00:00:00Z",null,DateTimeStyles.AdjustToUniversal);var to=from.AddMonths(1);
 var ticks=TickInput.Read(parts[1]);foreach(var sim in sims){sim.Month(ticks,from,to);sim.Save(resultDir);}Console.WriteLine("MONTH_DONE "+parts[0]);Console.Out.Flush();GC.Collect();}
foreach(var sim in sims)sim.Save(resultDir);Console.WriteLine("ALL_DONE");

record Config(string Name,double BrokerDelay,double AckDelay,double Cost,bool Xau,bool Eur,bool Macro);
readonly record struct Quote(long T,byte S,double Bid,double Ask);
static class TickInput{
 public static Quote[] Read(string path){using var f=File.OpenRead(path);using var b=new BinaryReader(f);long count=f.Length/25;if(f.Length%25!=0||count>int.MaxValue)throw new Exception("BAD_BINARY_LENGTH");var q=new Quote[(int)count];for(int i=0;i<q.Length;i++){long ms=b.ReadInt64();byte s=b.ReadByte();q[i]=new(DateTime.UnixEpoch.Ticks+ms*10000,s,b.ReadDouble(),b.ReadDouble());if(i>0&&q[i].T<q[i-1].T)throw new Exception("TICK_REWIND");}return q;}
}
sealed class Gates{
 public (DateTime At,int Buy,int Sell)[] Values=Array.Empty<(DateTime,int,int)>();
 public static Gates Read(string path){using var f=new GZipStream(File.OpenRead(path),CompressionMode.Decompress);var a=JsonSerializer.Deserialize<JsonElement[]>(f)!;return new(){Values=a.Select(v=>(DateTime.Parse(v[0].GetString()!,CultureInfo.InvariantCulture,DateTimeStyles.AdjustToUniversal|DateTimeStyles.AssumeUniversal),v[1].GetInt32(),v[2].GetInt32())).ToArray()};}
 public bool Ok(DateTime t,int side){int l=0,r=Values.Length;while(l<r){int m=(l+r)/2;if(Values[m].At<=t)l=m+1;else r=m;}return l>0&&(side==1?Values[l-1].Buy:Values[l-1].Sell)==1;}
}
sealed class TickSimulation{
 readonly Config cfg;readonly Data xd,ed;readonly Tape xt,et;readonly Gates gates;readonly Host host=new();readonly List<Leg> legs=new();readonly DateTime[] signalTimes;
 readonly List<object> monthly=new(),curve=new(),blocks=new(),liquidations=new();readonly HashSet<string> basketIds=new();
 readonly Dictionary<string,(DateTime At,string Symbol,double Pnl,int Children,int Stage)> basketLedger=new();
 Quote[] ticks=Array.Empty<Quote>();int qi;long clock;DateTime nextTimer;DateTime lastMinute=DateTime.MinValue;long totalTicks,sampleBucket=-1;double peak=100,dd,balPeak=100,balDd,maxMargin;int macroBlocks;string processed="";long timers;int historyRecorded;bool brokerBusy;
 public TickSimulation(Config c,Data x,Data e,Tape tx,Tape te,Gates g){cfg=c;xd=x;ed=e;xt=tx;et=te;gates=g;signalTimes=(c.Xau?xt.Signals.Keys:Enumerable.Empty<DateTime>()).Concat(c.Eur?et.Signals.Keys:Enumerable.Empty<DateTime>()).Distinct().OrderBy(t=>t).ToArray();host.EnableXau=c.Xau;host.EnableEur=c.Eur;host.EnableTrading=true;host.ExpectedAccount=host.Account.Number.ToString();host.BridgeUrl="wss://example.invalid:25345";host.BridgeToken="offline-research-fixture";host.FeeFactor=c.Cost;host.Account.PreciseLeverage=200;host.BeforeMarketFill=BrokerWait;host.AfterAccountMutation=Observe;host.CreateEngines();if(c.Eur)legs.Add(new(host.Eur!,false,host));if(c.Xau)legs.Add(new(host.Xau!,true,host));}
 bool Active=>host.Positions.Count>0||legs.Any(l=>l.Basket!=null||l.Acks.Count>0||!string.IsNullOrEmpty((string)l.State.PendingLabel));
 DateTime Now=>new(clock,DateTimeKind.Utc);
 void Time(long t){if(t<clock)throw new Exception("CLOCK_REWIND");clock=t;host.Server.TimeInUtc=Now;}
 void Observe(){host.Mark();peak=Math.Max(peak,host.Account.Equity);dd=Math.Max(dd,(peak-host.Account.Equity)/peak);balPeak=Math.Max(balPeak,host.Account.Balance);balDd=Math.Max(balDd,(balPeak-host.Account.Balance)/balPeak);if(host.Account.Equity>0)maxMargin=Math.Max(maxMargin,host.Account.Margin/host.Account.Equity);if(clock/TimeSpan.TicksPerHour!=sampleBucket){sampleBucket=clock/TimeSpan.TicksPerHour;curve.Add(new{At=Now,Balance=host.Account.Balance,Equity=host.Account.Equity,DrawdownPct=100*(peak-host.Account.Equity)/peak});}}
 void Capture(){while(historyRecorded<host.History.Count){var h=host.History[historyRecorded++];var key=string.Join('|',h.Label.Split('|').Take(2));var old=basketLedger.GetValueOrDefault(key,(h.EntryTime,h.SymbolName,0d,0,0));int children=(int)Math.Round(h.VolumeInUnits/(h.SymbolName=="XAUUSD"?1:1000));int stage=int.Parse(h.Label.Split('|')[2]);basketLedger[key]=(old.Item1,old.Item2,old.Item3+h.NetProfit,old.Item4+children,Math.Max(stage,old.Item5));}}
 void Apply(Quote q){Time(q.T);totalTicks++;string symbol=q.S==0?"EURUSD":"XAUUSD";var s=host.Symbols.GetSymbol(symbol);s.Bid=q.Bid;s.Ask=q.Ask;
  if(host.Positions.Count>0){Observe();foreach(var p in host.Positions.ToArray()){if(p.SymbolName!=symbol)continue;int side=p.TradeType==TradeType.Buy?1:-1;double ex=side==1?s.Bid:s.Ask;if(side*(ex-p.StopLoss!.Value)<=0||side*(ex-p.TakeProfit!.Value)>=0)host.ClosePosition(p);}
   // EUR source has OnTick position management. XAU uses its one-second timer.
   if(q.S==0&&host.Eur!=null&&!brokerBusy)host.Eur.OnTick();Observe();
   if(host.Account.Margin>0&&host.Account.Equity<=host.Account.Margin*.5){liquidations.Add(new{At=Now,host.Account.Equity,host.Account.Margin,AssumedStopOutPct=50});foreach(var p in host.Positions.OrderBy(p=>p.NetProfit).ToArray()){host.ClosePosition(p);if(host.Account.Margin==0||host.Account.Equity>host.Account.Margin*.5)break;}}
  }Capture();
 }
 void Advance(long to){while(qi<ticks.Length&&ticks[qi].T<=to)Apply(ticks[qi++]);Time(to);}
 void BrokerWait(){if(cfg.BrokerDelay<=0)return;brokerBusy=true;try{Advance(clock+(long)(cfg.BrokerDelay*TimeSpan.TicksPerSecond));}finally{brokerBusy=false;}}
 void Feed(Leg l,DateTime at,DateTime? signalOverride=null){if(!l.IsXau)return;if(!cfg.Macro){l.Set("_snapshot",null!);return;}int side=l.Basket==null?1:(int)l.Basket.Side;DateTime signalAt=signalOverride??(l.Basket==null?at:(DateTime)l.Basket.AtUtc);
  bool buy=gates.Ok(signalAt,1),sell=gates.Ok(signalAt,-1);
  l.Set("_snapshot",new X.ExternalSnapshot{ProducedUtc=at,CoverageFromUtc=signalAt.AddMinutes(-30),CoverageToUtc=signalAt.AddMinutes(495),ForexFactoryOk=true,BlsOk=true,Dfii10=new(){Delta=buy?-1:1,AvailableUtc=signalAt},Dgs10=new(){Delta=sell?1:-1,AvailableUtc=signalAt}});
 }
 void Cycle(DateTime scheduledAt){timers++;
  foreach(var l in legs){var time=Now;var at=X.FrozenCore.Floor(time,1);bool minute=at.AddMinutes(-1)>(DateTime)l.State.LastBarUtc;l.Set("_lastBridgeAck",time);Feed(l,time);l.Call("ManagePositions",time);Capture();
   if(minute){l.State.PeakEquity=Math.Max((double)l.State.PeakEquity,host.Account.Equity);if(l.IsXau&&l.Basket!=null){dynamic b=l.Basket;int j=xd.Lower(at.AddMinutes(-1));if(j<xd.Rows.Length&&xd.Rows[j].At==at.AddMinutes(-1)&&xd.Rows[j].At>=(DateTime)b.AtUtc){var r=xd.Rows[j];double extreme=(int)b.Side==1?r.Low+host.Symbols.GetSymbol(l.Symbol).Ask-host.Symbols.GetSymbol(l.Symbol).Bid:r.High;b.MaxDepthPrevious=Math.Max((double)b.MaxDepthPrevious,(int)b.Side*((double)b.Entry-extreme)/Math.Abs((double)b.Entry-(double)b.Stop));}
    var ca=X.FrozenCore.Floor(at,5);double fill=((int)b.Side==1?host.Symbols.GetSymbol(l.Symbol).Ask:host.Symbols.GetSymbol(l.Symbol).Bid)+(int)b.Side*.1;
    if(host.Positions.Any(p=>p.SymbolName==l.Symbol)&&(int)b.QueueStage<0&&(int)b.NextStage<X.FrozenContract.Xau.Stages&&at<=((DateTime)b.AtUtc).AddMinutes(90)&&xt.Confirmations.GetValueOrDefault(ca)==(int)b.Side&&ca!=(DateTime)b.LastConfirmationUtc&&(double)b.MaxDepthPrevious>=X.FrozenContract.Xau.Depths[(int)b.NextStage]&&(int)b.Side*((double)b.Entry-fill)>=.05*Math.Abs((double)b.Entry-(double)b.Stop)){b.LastConfirmationUtc=ca;l.Call("QueueStage",(int)b.NextStage,fill);}}
    l.State.LastBarUtc=at.AddMinutes(-1);l.Call("Changed");var tape=l.IsXau?xt:et;
    SignalPoint? sp=null;if(l.Basket==null&&tape.Signals.TryGetValue(at,out sp)&&host.PortfolioReady&&host.NoForeignExposure()&&at>(DateTime)l.State.LastRealExitUtc&&at>(DateTime)l.State.LastSignalUtc){
     if(l.IsXau){var sig=(X.Signal)sp.Signal;if(!cfg.Macro||!gates.Ok(at,sig.Side))macroBlocks++;Feed(l,Now,at);}else{l.State.Eur.Fast=sp.Fast;l.State.Eur.Slow=sp.Slow;}
     l.Call("PrepareBasket",sp.Signal,Now);if(l.Basket==null&&blocks.Count<100000)blocks.Add(new{At=Now,Symbol=l.Symbol,Reason=l.Type.GetField("_status",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(l.Context)});
    }
   }
   if(!l.IsXau&&l.Basket!=null){dynamic b=l.Basket;var s=host.Symbols.GetSymbol(l.Symbol);double quote=(int)b.Side==1?s.Ask:s.Bid;if((int)b.QueueStage<0&&(int)b.NextStage<E.F0245Policy.Contract.Stages&&host.Positions.Any(p=>p.SymbolName==l.Symbol)&&Now<=((DateTime)b.AtUtc).AddMinutes(210)&&(int)b.Side*((double)b.Entry-quote)/Math.Abs((double)b.Entry-(double)b.Stop)>=E.F0245Policy.Contract.Depths[(int)b.NextStage])l.Call("QueueStage",(int)b.NextStage,quote);}
   l.Call("ProcessQueue",Now);l.Call("Persist");l.Pump(Now,cfg.AckDelay);if((bool)l.State.Quarantined)throw new Exception(cfg.Name+" QUARANTINE "+(string)l.State.QuarantineReason);
  }Observe();Capture();
 }
 public void Month(Quote[] q,DateTime from,DateTime to){ticks=q;qi=0;if(clock==0){clock=from.Ticks;nextTimer=from;}double startBalance=host.Account.Balance;long tickStart=totalTicks;bool active=Active;DateTime searched=DateTime.MinValue;
  while(clock<to.Ticks){if(nextTimer.Ticks<clock)nextTimer=new DateTime(clock-clock%TimeSpan.TicksPerSecond+TimeSpan.TicksPerSecond,DateTimeKind.Utc);if(!active&&nextTimer!=searched){int j=Array.BinarySearch(signalTimes,nextTimer);if(j<0)j=~j;nextTimer=j<signalTimes.Length?signalTimes[j]:to;searched=nextTimer;}
   long nextTick=qi<ticks.Length?ticks[qi].T:long.MaxValue;long next= Math.Min(nextTick,nextTimer.Ticks);
   if(next>=to.Ticks){Time(to.Ticks);break;}if(nextTick<=nextTimer.Ticks){Apply(ticks[qi++]);continue;}
   Time(nextTimer.Ticks);var scheduled=nextTimer;Cycle(scheduled);active=Active;nextTimer=scheduled.AddSeconds(active?1:60);
   if(!active)nextTimer=X.FrozenCore.Floor(nextTimer,1);
  }
  if(qi!=q.Length)throw new Exception("UNPROCESSED_MONTH_TICKS "+qi+"/"+q.Length);processed=from.ToString("yyyy-MM");Observe();Capture();
  monthly.Add(new{Month=processed,StartBalance=startBalance,EndBalance=host.Account.Balance,Equity=host.Account.Equity,NetProfit=host.Account.Balance-startBalance,Ticks=totalTicks-tickStart,OpenPositions=host.Positions.Count});curve.Add(new{At=to,Balance=host.Account.Balance,Equity=host.Account.Equity,MaxDDPct=dd*100});ticks=Array.Empty<Quote>();Console.Error.WriteLine(cfg.Name+" "+processed+" balance="+host.Account.Balance+" orders="+host.Requests);
 }
 public void Save(string dir){Capture();Observe();double err=100+host.History.Sum(h=>h.NetProfit)+host.Positions.Sum(p=>p.Commissions+p.Swap)-host.Account.Balance;if(Math.Abs(err)>Math.Max(.00001,Math.Abs(host.Account.Balance)*1e-10))throw new Exception("CASH_RECONCILIATION "+err);
  var bs=basketLedger.Select(p=>new{Id=p.Key,Entry=p.Value.At,Symbol=p.Value.Symbol,Pnl=p.Value.Pnl,Children=p.Value.Children,MaxStage=p.Value.Stage,StillOpen=host.Positions.Any(x=>x.Label.StartsWith(p.Key+"|"))}).ToArray();double gain=bs.Sum(b=>Math.Max(0,b.Pnl)),loss=bs.Sum(b=>Math.Max(0,-b.Pnl));
  var r=new{Status="PARTIAL_PARITY",Config=cfg,ProcessedThrough=processed,RealTicks=true,MacroVintageCertified=false,RawCommissionVerified=false,SourceMethodsUsed=true,FullPlatformLifecycle=false,StartingBalance=100,EndingBalance=host.Account.Balance,EndingEquity=host.Account.Equity,EndingMargin=host.Account.Margin,EndingUnrealizedPnl=host.Account.Equity-host.Account.Balance,NetProfit=host.Account.Balance-100,MaximumFloatingDDPct=dd*100,MaximumBalanceDDPct=balDd*100,ProfitFactor=loss>0?gain/loss:(double?)null,WinRate=bs.Length>0?100d*bs.Count(b=>b.Pnl>0)/bs.Length:0,TotalBaskets=bs.Length,TotalChildOrders=bs.Sum(b=>b.Children),BrokerRequests=host.Requests,host.MarginRejects,host.VolumeRejects,PortfolioBudgetBlocks=host.PortfolioBudgetBlocks,MacroBlockedSignals=macroBlocks,TotalTicks=totalTicks,TimerCalls=timers,MaxMarginPct=maxMargin*100,CashReconciliationError=err,OpenPositions=host.Positions.Count,Ledger=host.History,Orders=host.OrderEvents,Baskets=bs,Blocks=blocks,Liquidations=liquidations,Monthly=monthly,EquityCurve=curve};
  File.WriteAllText(Path.Combine(dir,cfg.Name+".json"),JsonSerializer.Serialize(r,new JsonSerializerOptions{WriteIndented=true}));
 }
}
