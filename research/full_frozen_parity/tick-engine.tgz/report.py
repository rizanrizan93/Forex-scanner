from pathlib import Path
import sys,json,csv,hashlib,zipfile,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

audit=Path(sys.argv[1]);root=Path(sys.argv[2]);results=root/'replay_results';quality=json.loads((audit/'data_quality.json').read_text()) if (audit/'data_quality.json').exists() else {}
reports=[]
for p in sorted(results.glob('*.json')) if results.exists() else []:
 try:
  r=json.loads(p.read_text())
  if 'Config' in r:reports.append(r)
 except Exception:pass
complete=len(reports)==8 and all(r['ProcessedThrough']=='2026-03' and len(r['Monthly'])==87 for r in reports)
summary={'status':'PARTIAL_PARITY' if complete else 'NOT_VALIDATED','complete_eight_scenario_period':complete,'audit_files':quality.get('processed_files',0),'audit_ticks':quality.get('total_ticks'),'scenarios':[{k:v for k,v in r.items() if k not in ['Ledger','Orders','Baskets','Blocks','Liquidations','Monthly','EquityCurve']} for r in reports]}
pilot=[]
for r in reports:
 p=root/'pilot'/(r['Config']['Name']+'.json')
 if p.exists():
  pr=json.loads(p.read_text());ok=pr['Monthly']==r['Monthly'][:3];pilot.append({'scenario':r['Config']['Name'],'quarterly_state_replay_equal':ok})
summary['pilot_reconciliation']=pilot
if pilot and not all(x['quarterly_state_replay_equal'] for x in pilot):summary['status']='NOT_VALIDATED'
(root/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
(root/'CONFIG.json').write_text(json.dumps({'period_start':'2019-01-01T00:00:00Z','period_end_exclusive':'2026-04-01T00:00:00Z','initial_equity_usd':100,'deposits':0,'leverage':200,'frozen_source_optimized':False,'macro_point_in_time_certified':False,'scenarios':[r['Config'] for r in reports]},indent=2))
lines=['# RIZAN — real tick replay and frozen source audit','',f"**Status: {summary['status']}**. Full frozen parity has NOT been certified.",'','Period requested: 2019-01-01 through 2026-03-31 UTC. Shared account $100, no deposits, linear leverage 1:200. Each scenario starts independently with $100.','',f"Audit scanned {quality.get('processed_files',0)}/174 files; total ticks: {quality.get('total_ticks','not yet available')}. All inspected price data retain original duplicate timestamps and original sequence. No interpolation. Gaps are listed as review candidates, not certified exchange-calendar exclusions.",'','## Source and execution scope','','The ten strategy C# files are byte-frozen from RIZAN_PORTFOLIO_SETTLEMENT_V1_1_1_20261017.zip. SOURCE_SHA256.json records their checksums. Signal functions, ATR, F0245 policy, sizing, batch, portfolio budget, post-fill recheck and settlement methods execute from these files. SourceTape.cs is adapted from the archived source replay harness, not Stage-0. Source files are not optimized.','',
'XAU BUY: regression band reclaim on closed M5 with strict EMA50/EMA200 M15/H1 regime; SELL: prior-24-M5 high sweep followed by reversal within three bars, with M15/H1 down regime. Source entry window is 12:00–16:59 UTC (19:00–23:59 WIB). EUR: M15 sweep/reclaim of the preceding eight bars, neutral H1 EMA50 bias, body threshold ±0.2, 07:00–11:59 UTC (14:00–18:59 WIB). These are the actual source definitions; no substitute Donchian strategy is used.','',
'XAU: three stages at depth 0/.2/.4, confirmed additions within 90 min; 2.4 ATR/structural anchor stop, 5.5R target, 12.1% cap, balance step $102.5, three-day loss cooldown. EUR F0245: base 3 ATR distance clamped .0005–.006 then ×.845, 10R target, three stages within 210 min, feedback fast/slow degear, 2R cost-adjusted break-even. Shared entry risk cap 20.75%, shared margin cap 50%. Full constants and algorithms remain in the source.','',
'## Material limitations — why results remain PARTIAL_PARITY','','1. The archived XAU macro permissions are reconstructed flags, not certified vintage snapshots. The flags are provided only in explicitly named ARCHIVED_FLAGS experiments. Synthetic ExternalSnapshot envelopes reproduce those permissions and must not be interpreted as historical Forex Factory/BLS feed records. The STRICT_MISSING_MACRO experiment leaves snapshots unavailable, so frozen XAU must block. It is not a gate-disabled XAU strategy.','',
'2. Commissions are archived model assumptions, not verified RAW-account specifications: EUR $3 per 100k per side, XAU $.03 per ounce per side ($3 per 100oz lot). Base extra slippage: EUR .00001 and XAU $.05 per side. Cost stress scales these fees and slippage; original bid/ask spread is never multiplied. Therefore scenario B is a 2s MODEL experiment, not verified broker-realistic performance.','',
'3. The adapter uses exact source internal methods plus precalculated causal signal/feedback tapes from tick-derived M1. It does not reproduce the complete platform OnStart/OnTimer lifecycle or independently certify every callback/recovery path. Original regression tests and sampled source/tape parity tests are evidence of components, not proof of complete lifecycle equivalence. Actual EUR OnTick management runs on each EUR quote; XAU runs at one-second timers.','',
'4. No pre-2019 real tick warmup was supplied. Signal warmup begins in January 2019; there are no pre-2019 account trades. EUR virtual feedback begins from this history as well. This differs from the archived 2016 start and its longer prehistory.','',
'5. Margin is a fixed linear 1:200 model; min volume 1 oz XAU/1,000 EUR units, max 2,000 oz/2m EUR units, step equal to minimum. A 50% margin-level stop-out is an explicit unverified model assumption. No order-book liquidity, market impact, tier leverage or stochastic partial fills/outages are modeled.','',
'6. Same-millisecond ties preserve file order within each symbol and use EUR before XAU across symbols. Cross-symbol ordering inside the same timestamp is not observed. During a synchronous broker request, all real ticks continue to update quotes, broker stops and equity; strategy timer and OnTick callbacks wait until the request returns. Delay changes both request and checkpoint ACK delay in the D scenarios.','',
'7. All candles are aggregated from original BID ticks. M1 aggregates are input features, never execution-price paths. Signals reference closed bars only; tape parity tests sample source prefix recomputation. A full future-data perturbation proof and native platform replay remain outstanding. Calendar-certified gap acceptance is also outstanding.','',
'8. Source mandates daily exits by 19:59 UTC XAU / 20:00 UTC EUR, before modeled NY rollover. No overnight swap is charged here; any residual overnight exposure must invalidate that simplification. Remaining final positions are marked at the last quote, never silently forced closed.','',
'## Scenario metrics','','| Scenario | End balance USD | Floating DD % | Balance DD % | PF | Win % | Baskets | Virtual children | Requests | Margin rejects | End |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|']
for r in reports:
 vals=[r['Config']['Name'],f"{r['EndingBalance']:,.2f}",f"{r['MaximumFloatingDDPct']:.2f}",f"{r['MaximumBalanceDDPct']:.2f}",str(round(r['ProfitFactor'],4)) if r['ProfitFactor'] is not None else 'n/a',f"{r['WinRate']:.2f}",r['TotalBaskets'],r['TotalChildOrders'],r['BrokerRequests'],r['MarginRejects'],r['ProcessedThrough']]
 lines.append('| '+' | '.join(map(str,vals))+' |')
lines+=['','Virtual children means accepted/closed volume divided by .01-lot child size, including closed rejected fills; broker requests and actual batched positions are distinct. Baskets aggregate realized PnL by original source basket label. See detailed ledgers for open/rejected cases.','',
'## Reconciliation and detailed files','','Cash equation: balance = $100 + sum(history net PnL) + opening commissions/swap of still-open positions. Floating equity uses current executable bid/ask. Every input tick is processed chronologically for each scenario. SL/TP triggers use actual sequential quotes. Equity drawdown is measured at every tick while exposed, before/after broker exits and source management; plotted curves are hourly samples plus month ends and can visually understate intrahour extremes. Maximum balance drawdown includes commission debits.','',f'Q1 pilot comparisons: {json.dumps(pilot)}. Full-period completion: {complete}.','',
'Old $90.73m evidence covers 2016–October 2026 with synthetic M1 paths, different prehistory, price source and cost assumptions. No same-period replay has isolated these causes here. Differences are not attributable to tick data alone and cannot be interpreted as a forecast. No live orders, bridge restarts, production environment changes or main-branch merge were authorized or performed by this research workflow.','']
for r in reports:
 name=r['Config']['Name'];d=results/name;d.mkdir(exist_ok=True)
 def writecsv(path,rows):
  if not rows:return
  with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 writecsv(d/'child_position_ledger.csv',r['Ledger']);writecsv(d/'basket_ledger.csv',r['Baskets']);writecsv(d/'monthly.csv',r['Monthly']);writecsv(d/'orders.csv',r['Orders']) if r['Orders'] and len({tuple(x.keys()) for x in r['Orders']})==1 else None
 annual=[]
 for y in range(2019,2027):
  ms=[m for m in r['Monthly'] if m['Month'].startswith(str(y))]
  if ms:annual.append({'Year':y,'Start':ms[0]['StartBalance'],'End':ms[-1]['EndBalance'],'NetProfit':sum(m['NetProfit'] for m in ms)})
 writecsv(d/'annual.csv',annual)
 if r['Monthly']:
  best=max(r['Monthly'],key=lambda m:m['NetProfit']);worst=min(r['Monthly'],key=lambda m:m['NetProfit'])
  stats={'best_month':best,'worst_month':worst,'baskets_per_month':r['TotalBaskets']/len(r['Monthly']),'contribution':{s:sum(h['NetProfit'] for h in r['Ledger'] if h['SymbolName']==s) for s in ['XAUUSD','EURUSD']},'layering_by_max_stage':{str(i):{'baskets':sum(b['MaxStage']==i for b in r['Baskets']),'pnl':sum(b['Pnl'] for b in r['Baskets'] if b['MaxStage']==i)} for i in range(3)},'commission_total':sum(h['TotalCommission'] for h in r['Ledger']),'slippage_dollars_total':sum(h.get('SlippageDollars',0) for h in r['Ledger']),'spread_dollars_vs_mid_benchmark':sum(h.get('SpreadVsMidDollars',0) for h in r['Ledger']),'MFE_dollars':{},'MAE_dollars':{}}
  for field,key in [('Mfe','MFE_dollars'),('Mae','MAE_dollars')]:
   z=[h[field] for h in r['Ledger']];stats[key]={'mean':float(np.mean(z)),'median':float(np.median(z)),'p95':float(np.quantile(z,.95))} if z else {}
  (d/'diagnostics.json').write_text(json.dumps(stats,indent=2))
  lines+=['### '+name,'',f"Best realized month: {best['Month']} ${best['NetProfit']:,.2f}; worst: {worst['Month']} ${worst['NetProfit']:,.2f}. Baskets/month: {stats['baskets_per_month']:.2f}. Contribution XAU/EUR: {stats['contribution']}. Cash discrepancy: ${r['CashReconciliationError']:.10f}. Liquidations: {len(r['Liquidations'])}. Open positions: {r['OpenPositions']}.",'']
  q=r['EquityCurve'];fig,ax=plt.subplots(2,1,figsize=(11,7),sharex=True);times=[x['At'][:19] for x in q];from datetime import datetime;ts=[datetime.fromisoformat(t) for t in times];ax[0].plot(ts,[x['Equity'] for x in q],lw=.8);ax[0].set_ylabel('Equity USD');ax[0].set_title(name+' — PARTIAL PARITY');ax[0].grid(alpha=.2);ax[1].fill_between(ts,[x.get('DrawdownPct',0) for x in q],color='#b23b47',alpha=.5);ax[1].set_ylabel('Sampled DD %');ax[1].invert_yaxis();fig.tight_layout();fig.savefig(d/'equity_drawdown.png',dpi=150);plt.close(fig)
(root/'REPORT.md').write_text('\n'.join(lines))
shutil.copytree(audit,root/'data_audit',dirs_exist_ok=True)
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.suffix not in ['.tgz','.zip','.dll'] and p.name not in ['MANIFEST_SHA256.json','month.bin']}
(root/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(root/'RIZAN_FROZEN_TICK_AUDIT.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in root.rglob('*'):
  if p.is_file() and p.name!='month.bin' and p.suffix not in ['.tgz','.zip','.dll']:z.write(p,str(p.relative_to(root)))
print(json.dumps(summary,indent=2))
