from pathlib import Path
import argparse,subprocess,json,hashlib,os,sys,shutil,urllib.request,time
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pyarrow.parquet as pq
import pandas as pd

p=argparse.ArgumentParser();p.add_argument('--target',required=True);p.add_argument('--key',required=True);p.add_argument('--hosts',required=True);p.add_argument('--audit',required=True);p.add_argument('--out',required=True);p.add_argument('--months',type=int,default=87);a=p.parse_args()
r=Path(__file__).resolve().parent;out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True);audit=Path(a.audit).resolve()
for file,sha in json.loads((r/'SOURCE_SHA256.json').read_text()).items():assert hashlib.sha256((r/'source'/file).read_bytes()).hexdigest()==sha
sdk=Path(os.environ['DOTNET_ROOT']);refs=next((sdk/'packs/Microsoft.NETCore.App.Ref').glob('*/ref/net8.0'));csc=next((sdk/'sdk').glob('*/Roslyn/bincore/csc.dll'))
args=['-nologo','-target:exe','-langversion:latest','-nullable:enable','-define:REPLAY','-out:'+str(out/'TickReplay.dll')]+['-r:'+str(x) for x in refs.glob('*.dll')]+[str(x) for x in (r/'source').rglob('*.cs')]+[str(r/n) for n in ['ApiStubs.cs','tests/Global.cs','SourceTape.cs','TickReplay.cs']]
(out/'build.rsp').write_text('\n'.join(args))
subprocess.run([str(sdk/'dotnet'),str(csc),'@'+str(out/'build.rsp')],check=True)
(out/'TickReplay.runtimeconfig.json').write_text(json.dumps({'runtimeOptions':{'tfm':'net8.0','framework':{'name':'Microsoft.NETCore.App','version':'8.0.0'}}}))
if os.environ.get('RIZAN_COMPILE_ONLY')=='1':sys.exit(0)
opts=['-i',a.key,'-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+a.hosts,'-o','ConnectTimeout=30']
checks={x['file']:x['sha256'] for x in json.loads((audit/'data_quality.json').read_text())['files']}
months=[f'{y}-{m:02}' for y in range(2019,2027) for m in range(1,13) if (y,m)<=(2026,3)][:a.months]
log=(out/'progress.log').open('w');engine=subprocess.Popen([str(sdk/'dotnet'),str(out/'TickReplay.dll'),str(audit),str(out),str(r)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,bufsize=1)
def wait_for(prefix):
 while True:
  line=engine.stdout.readline()
  if not line:raise RuntimeError('ENGINE_DIED '+str(engine.poll()))
  print(line.strip(),flush=True)
  if line.startswith(prefix):return
wait_for('READY_FOR_MONTHS')
def fetch(sym,ym):
 name=f'{sym}_{ym}.parquet';path=out/name
 url=f'https://huggingface.co/datasets/Henrik404/dukascopy-ticks/resolve/main/data/{sym}/{name}?download=true'
 for attempt in range(3):
  try:
   with urllib.request.urlopen(url,timeout=120) as response,path.open('wb') as f:
    while b:=response.read(1024*1024):f.write(b)
   assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==checks[name]
   return path
  except Exception:
   if attempt==2:raise
   time.sleep(2)
pool=ThreadPoolExecutor(max_workers=4);future={}
for ym in months[:2]:
 for sym in ['EURUSD','XAUUSD']:future[(sym,ym)]=pool.submit(fetch,sym,ym)
for ym in months:
 parts=[]
 for sym,id,scale in [('EURUSD',0,100000),('XAUUSD',1,1000)]:
  name=f'{sym}_{ym}.parquet';path=future.pop((sym,ym)).result()
  assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==checks[name]
  pf=pq.ParquetFile(path);assert int(pf.metadata.metadata[b'point'])==scale
  d=pf.read(columns=['timestamp','bid','ask']).to_pandas();t=pd.to_datetime(d.timestamp,utc=True).astype("datetime64[ns, UTC]").astype('int64').to_numpy()//1000000
  b=np.empty(len(d),dtype=[('t','<i8'),('s','u1'),('bid','<f8'),('ask','<f8')]);b['t']=t;b['s']=id;b['bid']=d.bid.to_numpy(dtype=float)/scale;b['ask']=d.ask.to_numpy(dtype=float)/scale
  assert np.all(np.diff(t)>=0) and np.all(b['bid']<=b['ask'])
  parts.append(b);path.unlink();del d,t
 # Stable ties: EUR first, then XAU; within-symbol file order retained.
 data=np.concatenate(parts);del parts;order=np.argsort(data['t'],kind='stable');data=data[order];del order
 binary=out/'month.bin';data.tofile(binary);n=len(data);del data
 engine.stdin.write(ym+'|'+str(binary)+'\n');engine.stdin.flush();wait_for('MONTH_DONE '+ym);binary.unlink()
 print('TICK_MONTH_PROCESSED',ym,n,flush=True)
 i=months.index(ym)
 if i+2<len(months):
  for sym in ['EURUSD','XAUUSD']:future[(sym,months[i+2])]=pool.submit(fetch,sym,months[i+2])
 if os.environ.get('GH_TOKEN') and (ym.endswith('-12') or ym==months[-1]):
  from datetime import datetime,timezone
  summary=[]
  for pth in out.glob('*.json'):
   try:
    rr=json.loads(pth.read_text())
    if 'Config' in rr:summary.append({k:rr[k] for k in ['Config','ProcessedThrough','EndingBalance','MaximumFloatingDDPct','TotalBaskets','BrokerRequests','TotalTicks','CashReconciliationError']})
   except Exception:pass
  import base64
  endpoint='repos/rizanrizan93/Forex-scanner/contents/research/full_frozen_parity/RUN_PROGRESS.json';branch='research/tick-archive-2019-2026'
  body={'branch':branch,'message':'research: record '+out.name+' replay progress '+ym,'content':base64.b64encode(json.dumps({'updated_utc':datetime.now(timezone.utc).isoformat(),'phase':out.name,'month':ym,'scenarios':summary},indent=2).encode()).decode()}
  prior=subprocess.run(['gh','api',endpoint+'?ref='+branch],capture_output=True,text=True)
  if prior.returncode==0:body['sha']=json.loads(prior.stdout)['sha']
  req=out/'progress-write.json';req.write_text(json.dumps(body));subprocess.run(['gh','api','--method','PUT',endpoint,'--input',str(req)],stdout=subprocess.DEVNULL,check=True);req.unlink()
engine.stdin.write('DONE\n');engine.stdin.flush();wait_for('ALL_DONE');assert engine.wait()==0
log.close()
