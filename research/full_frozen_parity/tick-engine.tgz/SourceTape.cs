using System.Globalization;
using System.Reflection;
using System.Text.Json;
using cAlgo.API;
using Rizan.Portfolio;
using X=Rizan.Portfolio.Xau;
using E=Rizan.Portfolio.Eur;
record struct Row(DateTime At,double Open,double High,double Low,double Close,double Spread,int Roll,bool BuyOk,bool SellOk);
record Scenario(string Name,int Leverage,double Cost,double Delay,bool Adverse,double Risk,bool Xau,bool Eur,bool Bypass,int LastYear);
record SignalPoint(object Signal,double Fast=0,double Slow=0);
sealed record Tape(Dictionary<DateTime,SignalPoint> Signals,Dictionary<DateTime,int> Confirmations);
sealed class Data
{
 public Row[] Rows=Array.Empty<Row>();
 public static Data Load(string path,bool xau,int maxYear){var rows=new List<Row>();foreach(var line in File.ReadLines(path).Skip(1)){var p=line.Split(',');var at=DateTime.Parse(p[0],CultureInfo.InvariantCulture,DateTimeStyles.AdjustToUniversal|DateTimeStyles.AssumeUniversal);if(at.Year>maxYear)break;rows.Add(new(at,double.Parse(p[1],CultureInfo.InvariantCulture),double.Parse(p[2],CultureInfo.InvariantCulture),double.Parse(p[3],CultureInfo.InvariantCulture),double.Parse(p[4],CultureInfo.InvariantCulture),xau?double.Parse(p[5],CultureInfo.InvariantCulture):.00001,xau?int.Parse(p[6]):0,xau&&p[7]=="1",xau&&p[8]=="1"));}return new(){Rows=rows.ToArray()};}
 public static Tape XauTape(Data d){
  var raw=d.Rows.Select(r=>new X.Candle(r.At,r.Open,r.High,r.Low,r.Close)).ToList();var end=raw[^1].End(1);var m5=X.FrozenCore.Aggregate(raw,5,end);var m15=X.FrozenCore.Aggregate(raw,15,end);var h1=X.FrozenCore.Aggregate(raw,60,end);var atr=X.FrozenCore.Atr(m5);var candidates=X.FrozenCore.XauRaw(m5,atr,X.FrozenCore.AlignStrict(h1,60,m5),X.FrozenCore.AlignStrict(m15,15,m5));var signals=new Dictionary<DateTime,SignalPoint>();int hj=-1,mj=-1;
  for(int i=0;i<m5.Count;i++){var at=m5[i].End(5);while(hj+1<h1.Count&&h1[hj+1].End(60)<=at)hj++;while(mj+1<m15.Count&&m15[mj+1].End(15)<=at)mj++;if(i+1<100||hj+1<200||mj+1<200||at.Year<Period.StartYear||at.Hour<12||at.Hour>=17||at.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday)continue;var v=candidates[i];int side=v.Sell?-1:v.Buy?1:0;if(side!=0)signals[at]=new(new X.Signal(at,side,0,atr[i],side==1?v.BuyAnchor:v.SellAnchor));}
  var c5=m5.Where(x=>x.Count==5).ToList();var c15=m15.Where(x=>x.Count==15).ToList();var c60=h1.Where(x=>x.Count==60).ToList();var s15=X.FrozenCore.Strict(c15);var s60=X.FrozenCore.Strict(c60);var confirm=new Dictionary<DateTime,int>();hj=mj=-1;
  for(int i=1;i<c5.Count;i++){var a=c5[i];var at=a.End(5);while(hj+1<c60.Count&&c60[hj+1].End(60)<=at)hj++;while(mj+1<c15.Count&&c15[mj+1].End(15)<=at)mj++;if(hj<2||mj<1||(at-c15[mj].End(15)).TotalMinutes>15||(at-c60[hj].End(60)).TotalMinutes>60)continue;var b=c15[mj];int side=s60[hj];if(side!=s15[mj]||side==0)continue;if(side==1?a.Close>c5[i-1].High&&a.Close>a.Open&&b.Close>c15[mj-1].High&&b.Close>b.Open:a.Close<c5[i-1].Low&&a.Close<a.Open&&b.Close<c15[mj-1].Low&&b.Close<b.Open)confirm[at]=side;}
  int parity=0;foreach(var p in signals.Values.Take(12)){var s=(X.Signal)p.Signal;var v=X.FrozenCore.XauSignal(raw.Where(r=>r.OpenUtc<s.AtUtc).ToList(),s.AtUtc);if(v==null||v.Side!=s.Side||Math.Abs(v.Atr-s.Atr)>1e-8||Math.Abs(v.Anchor-s.Anchor)>1e-8)throw new Exception("XAU_SIGNAL_PARITY");parity++;}Console.WriteLine("XAU_SIGNAL_PARITY="+parity);int confirmationChecks=0;foreach(var c in confirm.Take(24)){if(!X.FrozenCore.XauConfirmation(raw.Where(r=>r.OpenUtc<c.Key).ToList(),c.Key,c.Value))throw new Exception("XAU_CONFIRMATION_PARITY");confirmationChecks++;}Console.WriteLine("XAU_CONFIRMATION_PARITY="+confirmationChecks);return new(signals,confirm);
 }
 public static Tape EurTape(Data d){
  var raw=d.Rows.Select(r=>new E.Candle(r.At,r.Open,r.High,r.Low,r.Close)).ToList();var end=raw[^1].End(1);var m15=E.FrozenCore.Aggregate(raw,15,end);var h1=E.FrozenCore.Aggregate(raw,60,end);var atr=E.FrozenCore.Atr(m15);var hr=new List<E.H1Record>();foreach(var h in h1){double ema=hr.Count==0?h.Close:2d/51*h.Close+49d/51*hr[^1].Ema;double slope=hr.Count>=3?ema-hr[^3].Ema:0;hr.Add(new(h.End(60),ema,h.Close>ema&&slope>0?1:h.Close<ema&&slope<0?-1:0));}
  var features=new Dictionary<DateTime,E.Feature>();int hj=-1;for(int i=0;i<m15.Count;i++){var b=m15[i];var at=b.End(15);while(hj+1<hr.Count&&hr[hj+1].AtUtc<=at)hj++;features[at]=new(at,b.Open,b.High,b.Low,b.Close,b.Count,atr[i],b.High>b.Low?(b.Close-b.Open)/(b.High-b.Low):double.NaN,i>=8?m15.Skip(i-8).Take(8).Max(x=>x.High):double.NaN,i>=8?m15.Skip(i-8).Take(8).Min(x=>x.Low):double.NaN,hj>=0?hr[hj].Bias:99);}
  var sample=raw.Take(12000).ToList();int compared=0;foreach(var f in E.FrozenCore.EurFeatures(sample,sample[^1].End(1),new E.EurState())){var a=features[f.AtUtc];if(a.Bias!=f.Bias||a.Count!=f.Count||Math.Abs(a.Atr-f.Atr)>1e-12||Math.Abs(a.Body-f.Body)>1e-12||Math.Abs(a.PriorHigh-f.PriorHigh)>1e-12||Math.Abs(a.PriorLow-f.PriorLow)>1e-12||E.FrozenCore.EurSignal(a)!=E.FrozenCore.EurSignal(f))throw new Exception("EUR_FEATURE_PARITY");compared++;}
  var signals=new Dictionary<DateTime,SignalPoint>();var state=new E.EurState();for(int i=0;i<raw.Count;i++){var b=raw[i];if(i>0&&state.Virtual!=null){var result=E.FrozenCore.VirtualStep(state.Virtual,raw[i-1]);if(result!=null){state.Fast=2d/3*result.Value.R+state.Fast/3;state.Slow=2d/9*result.Value.R+7d/9*state.Slow;state.LastExitUtc=result.Value.AtUtc;state.Virtual=null;}}var s=features.TryGetValue(b.OpenUtc,out var f)?E.FrozenCore.EurSignal(f):null;if(s==null)continue;signals[b.OpenUtc]=new(s,state.Fast,state.Slow);if(state.Virtual==null&&(state.LastExitUtc==default||b.OpenUtc>state.LastExitUtc))state.Virtual=new(){AtUtc=s.AtUtc,LastUtc=s.AtUtc,LastClose=b.Open,Side=s.Side,Distance=s.Distance,Entry=b.Open+(s.Side==1?.00012:0)+s.Side*.00001};}
  Console.WriteLine("EUR_FEATURE_PARITY="+compared);return new(signals,new());
 }
 public int Lower(DateTime at){int lo=0,hi=Rows.Length;while(lo<hi){int mid=(lo+hi)/2;if(Rows[mid].At<at)lo=mid+1;else hi=mid;}return lo;}
}

sealed class Host:RizanPortfolio {}
sealed class Leg
{
 readonly Host HostClock;public EngineContext Context;public bool IsXau;public string Symbol=>IsXau?"XAUUSD":"EURUSD";public string Prefix=>IsXau?"RZXRC1":"RZEF245";public Type Type;public WebSocketClient Socket=new();public int Sent;public long Remote;public Queue<(DateTime Due,long Client)> Acks=new();public object? Tracked;public double EntryBalance;public int BudgetAborts;
 public dynamic State=>Type.GetField("_state",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(Context)!;
 public dynamic? Basket=>State.Basket;
 public bool AccountingBlocked;public bool Active=>!AccountingBlocked&&((!(bool)State.Quarantined&&Basket!=null)||Acks.Count>0||HostClock.Positions.Any(p=>p.SymbolName==Symbol));
 public Leg(EngineContext c,bool xau,Host host){HostClock=host;Context=c;IsXau=xau;Type=xau?typeof(X.RizanRobot):typeof(E.RizanRobot);object state=xau?new X.Checkpoint{ContractHash=X.FrozenContract.Xau.Hash,ExecutionModel="XAU_BATCH_SEND_REF_COOLDOWN_V1",AccountNumber=host.Account.Number,Symbol="XAUUSD",PeakEquity=host.Account.Equity}:new E.Checkpoint{ContractHash=E.F0245Policy.ConfigHash,ExecutionModel=E.EurBatchExecution.Model,AccountNumber=host.Account.Number,Symbol="EURUSD",PeakEquity=host.Account.Equity};Set("_state",state);Set("_storageKey",Prefix+" fixture");Set("_bridge",Socket);Set("_bridgeReady",true);}
 public void Set(string n,object v)=>Type.GetField(n,BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(Context,v);
 public void Call(string n,params object[] args){try{Type.GetMethod(n,BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(Context,args);}catch(TargetInvocationException e){throw e.InnerException!;}}
 public void Pump(DateTime ignored,double delay){for(int repeat=0;repeat<100;repeat++){var at=HostClock.Server.TimeInUtc;while(Sent<Socket.Sent.Count){using var doc=JsonDocument.Parse(Socket.Sent[Sent++]);if(doc.RootElement.GetProperty("type").GetString()=="save")Acks.Enqueue((at.AddSeconds(delay),doc.RootElement.GetProperty("client_revision").GetInt64()));}if(Sent==Socket.Sent.Count){Socket.Sent.Clear();Sent=0;}if(Acks.Count==0||Acks.Peek().Due>at)return;var a=Acks.Dequeue();Call("ReceiveBridge",JsonSerializer.Serialize(new{type="ack",revision=++Remote,client_revision=a.Client}));}throw new Exception("ACK_LOOP");}
}


static class Period {public static int StartYear=2019;}
