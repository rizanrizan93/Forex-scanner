using cAlgo.API;
using Rizan.Portfolio;
record SeedConfig(int Base,int Sl,int Tp,int Hold,int Trend,int Session,int Risk,int Universe,int Day,int Threshold,int Direction=0,bool SeedOnly=false,double HandoffEquity=0,string RegimeChoice="fixed",double RearmEquity=0, SeedRule[]? Rules=null, double SatelliteUntil=0);
record SeedRule(string Id,int Symbol,int Base,int Sl,int Tp,int Hold,int Trend,int Session,int Risk,int Day,int Direction,
 string[]? Regimes=null, int Priority=0);
record SeedPoint(DateTime At,int Symbol,int Side,int Trend,double Atr,double Anchor,int Family=0,int Rule=-1);
static class SeedSettings {public static SeedConfig? Current;public static int LastYear;}
sealed class SeedController {
 readonly Host host;readonly SeedConfig? c;readonly double friction;readonly Action<HistoricalTrade> record;
 readonly Dictionary<DateTime,List<SeedPoint>> tape=new();
 int historyCursor;
 readonly Dictionary<long,(int Rule, RegimeRouter.State Regime, double Risk)> openRisk = new();
 readonly Dictionary<(int Rule,RegimeRouter.State Regime),(int Count,double Mean)> evidence = new();
 readonly Dictionary<string,int> choices = new();
 static readonly double[] Stops={.35,.75,1.25},Targets={1.5,2,3,4,5,8},Risks={.02,.03,.04,.05,.06,.08},Thresholds={150,200,300,500};
 static readonly int[] Holds={30,60,120,240,480},Days={1,2,4},Universes={7,1,2,4,3,6,5};static readonly string[] Symbols={"EURUSD","XAUUSD","BTCUSD"};
 DateTime deadline,nextEntry,day;int count;double peak=100,dd;bool halted;int requests,unaffordable,postfillCloses,entries;DateTime? graduated,firstGraduation;double graduationBalance;int rearms;
 double Goal=>c!.HandoffEquity>100?c.HandoffEquity:Thresholds[c.Threshold];
 public bool Enabled=>c!=null;public bool GrowthEnabled=>c==null||graduated!=null&&!c.SeedOnly;
 public IEnumerable<DateTime> SignalTimes=>tape.Keys;public bool Active=>host.Positions.Any(p=>p.Label.StartsWith("RZSEED|"));
 public SeedController(Host host,double friction,Action<HistoricalTrade> record){this.host=host;this.friction=friction;this.record=record;c=SeedSettings.Current;if(c==null)return;
  if(c.RearmEquity<0||c.RearmEquity>=Goal)throw new ArgumentException("INVALID_BOOTSTRAP_REARM");
  string root=Environment.GetEnvironmentVariable("SEED_DATA")??throw new Exception("SEED_DATA_MISSING");
  if(c.Rules is { Length: > 0 } rules)
  {
   if(c.RegimeChoice!="book"||rules.Select(r=>r.Id).Distinct().Count()!=rules.Length
      ||rules.Any(r=>r.Symbol<0||r.Symbol>2||r.Regimes?.Any(state=>!Enum.TryParse<RegimeRouter.State>(state,out _))==true))
    throw new ArgumentException("INVALID_STRATEGY_BOOK");
   for(int i=0;i<rules.Length;i++)
   {
    var rule=rules[i];
    Load(root,rule.Base,rule.Symbol,rule.Trend,rule.Direction,rule.Session,i);
   }
  }
  else
  {
   int[] families=c.RegimeChoice switch { "fixed"=>[c.Base],"short"=>[1,5,9],"long"=>[3,6,10],_=>throw new ArgumentException("INVALID_SEED_REGIME_CHOICE") };
   foreach(int baseId in families)
   for(int sid=0;sid<3;sid++)
    if((Universes[c.Universe]&(1<<sid))!=0)
     Load(root,baseId,sid,c.Trend,c.Direction,c.Session,-1);
  }
  foreach(var list in tape.Values)list.Sort((a,b)=>a.Symbol.CompareTo(b.Symbol));
 }
 void Load(string root,int baseId,int sid,int trendFilter,int direction,int session,int rule)
 {
  using var reader=new BinaryReader(File.OpenRead(Path.Combine(root,$"base{baseId}_symbol{sid}.bin")));
  if(reader.BaseStream.Length%40!=0)throw new Exception("SEED_TAPE_LAYOUT");
  while(reader.BaseStream.Position<reader.BaseStream.Length)
  {
   long minute=reader.ReadInt64();
   reader.ReadInt32();
   int symbol=reader.ReadInt32(),side=reader.ReadInt32(),trend=reader.ReadInt32();
   double atr=reader.ReadDouble(),anchor=reader.ReadDouble();
   var at=DateTime.UnixEpoch.AddMinutes(minute);
   if(at.Year<Period.StartYear||at.Year>SeedSettings.LastYear||(trend&(1<<trendFilter))==0
      ||direction==1&&side<0||direction==2&&side>0||!InSession(at,sid,session))continue;
   if(symbol!=sid||!double.IsFinite(atr)||atr<=0)throw new Exception("SEED_TAPE_INVALID");
   if(!tape.TryGetValue(at,out var list))tape[at]=list=new();
   list.Add(new(at,symbol,side,trend,atr,anchor,baseId%12/4,rule));
  }
 }
 public bool UseSatellite=>c is { Rules.Length: > 0 } && graduated!=null && !c.SeedOnly &&
     c.SatelliteUntil>0 && host.Account.Balance<c.SatelliteUntil;
 private IEnumerable<SeedPoint> Route(List<SeedPoint> points,DateTime at)
 {
  if(c!.Rules==null)return points;
  return points.Where(p=>Allowed(p,at)).OrderByDescending(p=>Score(p,at)).ThenBy(p=>p.Rule).ThenBy(p=>p.Symbol);
 }
 private bool Allowed(SeedPoint point,DateTime at)
 {
  var rule=c!.Rules![point.Rule];
  var regime=RegimeRouter.At(Symbols[point.Symbol],at);
  return rule.Regimes==null||rule.Regimes.Contains(regime.ToString(),StringComparer.Ordinal);
 }
 private (int Count,double Mean) Performance(SeedPoint point,DateTime at)
  => evidence.GetValueOrDefault((point.Rule,RegimeRouter.At(Symbols[point.Symbol],at)));
 private double Score(SeedPoint point,DateTime at)
 {
  var prior=Performance(point,at);
  return c!.Rules![point.Rule].Priority*.01 + prior.Mean*Math.Min(1,prior.Count/10d);
 }
 static bool InSession(DateTime at,int s,int z)=>z==0?at.Hour<20:z==1?s==0?at.Hour>=7&&at.Hour<12:s==1?at.Hour>=12&&at.Hour<17:at.Hour<20:z==2?at.Hour>=7&&at.Hour<12:at.Hour>=12&&at.Hour<17;
 public void Observe(){if(c==null||GrowthEnabled)return;peak=Math.Max(peak,host.Account.Equity);dd=Math.Max(dd,(peak-host.Account.Equity)/peak);}
 public void Manage(DateTime at){if(c==null)return;
  if(graduated!=null && c.Rules==null){
   if(c.RearmEquity==0||c.SeedOnly||at<graduated.Value.AddDays(20)||host.Positions.Count!=0||
      host.Account.Balance>=c.RearmEquity||host.Account.Equity>=c.RearmEquity)return;
   graduated=null;peak=host.Account.Equity;dd=0;halted=false;rearms++;
  }
  if(Active&&at>=deadline)foreach(var p in host.Positions.Where(p=>p.Label.StartsWith("RZSEED|")).ToArray())if(!host.ClosePosition(p).IsSuccessful)throw new Exception("SEED_EXPIRY_CLOSE");
  while(historyCursor<host.History.Count)
  {
   var h=host.History[historyCursor++];
   if(!h.Label.StartsWith("RZSEED|",StringComparison.Ordinal))continue;
   if(openRisk.Remove(h.PositionId,out var observed))
   {
    var key=(observed.Rule,observed.Regime);
    var old=evidence.GetValueOrDefault(key);
    double r=Math.Clamp(h.NetProfit/observed.Risk,-4,4);
    evidence[key]=(old.Count+1,old.Count==0?r:old.Mean+.12*(r-old.Mean));
   }
   record(h);nextEntry=h.ClosingTime.AddMinutes(h.NetProfit<0?60:5);
  }
  Observe();if(Active||graduated!=null)return;
  if(host.Account.Balance>=Goal&&host.Account.Equity>=Goal){graduated=at;firstGraduation??=at;graduationBalance=host.Account.Balance;return;}
  if(dd>=.6||host.Account.Balance<=0)halted=true;
 }
 static double Slip(int s,double p,double f)=>(s==0?.00001:s==1?.05:p*.0001)*f;
 static double Fee(int s,double p,double f)=>(s==0?.00003:s==1?.03:p*.0005)*f;
 public void Enter(DateTime at,double portfolioDrawdown=0)
 {
  if(c==null||graduated!=null&&!UseSatellite||halted||Active||host.Positions.Count!=0||
     at<nextEntry||!host.PortfolioReady||!host.NoForeignExposure()||!tape.TryGetValue(at,out var signals))return;
  if(at.Date!=day){day=at.Date;count=0;}
  foreach(var p in Route(signals,at)){
   string symbol=Symbols[p.Symbol];
   var rule=p.Rule<0?null:c.Rules![p.Rule];
   int stopIndex=rule?.Sl??c.Sl, targetIndex=rule?.Tp??c.Tp, holdIndex=rule?.Hold??c.Hold;
   int riskIndex=rule?.Risk??c.Risk, dayIndex=rule?.Day??c.Day;
   if(count>=Days[dayIndex])continue;
   double regimeFactor=c.RegimeChoice=="fixed"||rule!=null?1:RegimeRouter.SeedFactor(symbol,at,p.Side,p.Family);
   if(rule!=null)
   {
    var prior=Performance(p,at);
    if(prior.Count>=8&&prior.Mean<-.1)regimeFactor*=.55;
    regimeFactor*=portfolioDrawdown switch { >= .50=>.2, >= .40=>.5, >= .30=>.8, _=>1 };
    if(UseSatellite)regimeFactor*=.60;
   }
   if(regimeFactor<=0)continue;
   var sym=host.Symbols.GetSymbol(symbol);if(!sym.MarketHours.IsOpened(host.Server.TimeInUtc))continue;if(p.Symbol==2&&(at.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday||at.DayOfWeek==DayOfWeek.Friday&&at.Hour>=BrokerCalendar.CloseHour-1))continue;int sign=p.Side;double bid=sym.Bid,spread=sym.Ask-bid,entry=(sign>0?sym.Ask:bid)+sign*Slip(p.Symbol,bid,friction),anchor=p.Anchor+(sign<0?spread:0);
   if(sign*(bid-p.Anchor)<=0)continue;
   double distance=Math.Max(Math.Max(Stops[stopIndex]*p.Atr,sign*(entry-anchor)),p.Symbol==0?.00005:p.Symbol==1?.5:1),stop=entry-sign*distance,target=entry+sign*Targets[targetIndex]*distance;
   double ef=Fee(p.Symbol,entry,friction),xf=Fee(p.Symbol,target,friction),funding=p.Symbol==2?entry*.0003*Holds[holdIndex]/1440d*friction:0;
   double perRisk=distance+ef+xf+Slip(p.Symbol,bid,friction)+funding,entryCost=spread+Slip(p.Symbol,bid,friction)+ef;
   if((Targets[targetIndex]*distance-ef-xf-Slip(p.Symbol,bid,friction))/perRisk<.8)continue;
   double reference=Math.Min(host.Account.Balance,host.Account.Equity),risk=Risks[riskIndex]*regimeFactor,marginUnit=sym.GetEstimatedMargin(sign>0?TradeType.Buy:TradeType.Sell,sym.VolumeInUnitsMin)/sym.VolumeInUnitsMin;
   double units=sym.NormalizeVolumeInUnits(Math.Min(sym.VolumeInUnitsMax,Math.Min(reference*risk/(perRisk+risk*entryCost),reference*.5/(marginUnit+.5*entryCost))),RoundingMode.Down);
   if(units<sym.VolumeInUnitsMin){unaffordable++;continue;}
   deadline=new[]{at.AddMinutes(Holds[holdIndex]),at.Date.AddHours(20)}.Min();if(p.Symbol==2&&at.DayOfWeek==DayOfWeek.Friday)deadline=new[]{deadline,at.Date.AddHours(BrokerCalendar.CloseHour).AddMinutes(-30)}.Min();requests++;
   var result=host.Send(sign>0?TradeType.Buy:TradeType.Sell,sym.Name,units,$"RZSEED|{at.Ticks}|0|{requests}",distance/sym.PipSize,Targets[targetIndex]*distance/sym.PipSize,"annual seed research");
   count++;if(!result.IsSuccessful||result.Position==null){nextEntry=host.Server.TimeInUtc.AddMinutes(5);return;}
   var pos=result.Position;entries++;
   if(rule!=null)
   {
    choices[rule.Id]=choices.GetValueOrDefault(rule.Id)+1;
    openRisk.Add(pos.Id,(p.Rule,RegimeRouter.At(symbol,at),pos.VolumeInUnits*perRisk));
   }
   if(!host.Protect(pos,stop,target,ProtectionType.Absolute).IsSuccessful)throw new Exception("SEED_PROTECTION_FAILED");
   double actualRisk=pos.VolumeInUnits*(Math.Max(0,sign*(pos.EntryPrice-stop))+Fee(p.Symbol,pos.EntryPrice,friction)+Fee(p.Symbol,stop,friction)+Slip(p.Symbol,bid,friction)+funding);
   if(actualRisk>reference*risk+1e-8||host.Account.Margin>host.Account.Equity*.5+1e-8||sign*(target-(sign>0?sym.Bid:sym.Ask))<=0||sign*((sign>0?sym.Bid:sym.Ask)-stop)<=0){postfillCloses++;if(!host.ClosePosition(pos).IsSuccessful)throw new Exception("SEED_POSTFILL_CLOSE_FAILED");}
   Manage(host.Server.TimeInUtc);return;
  }
 }
 public object Audit()=>new{Enabled,c,HandoffEquity=c==null?0:Goal,Entries=entries,Requests=requests,UnaffordableMinLot=unaffordable,PostfillBudgetCloses=postfillCloses,GraduatedUtc=graduated,FirstGraduatedUtc=firstGraduation,Rearms=rearms,RuleFills=choices,GraduationBalance=graduationBalance,GrowthEnabled,Halted=halted,SeedMaxEquityDDPct=dd*100,SignalTimes=tape.Count};
}
