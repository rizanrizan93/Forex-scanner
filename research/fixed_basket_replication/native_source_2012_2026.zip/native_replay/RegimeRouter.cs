using System;
using System.Collections.Generic;

internal static class RegimeRouter
{
    internal enum State { WarmingUp, Range, Uptrend, Downtrend, Transition, Shock }
    private record struct Observation(DateTime ClosedAt, State Regime);
    private static readonly Dictionary<string, List<Observation>> Histories = new();
    private static readonly Dictionary<string, double> EntryFactors = new();
    private static readonly Dictionary<(string Symbol, State Regime, string Family), Count> Counts = new();
    private static readonly Dictionary<(string Symbol, State Regime, string Family), Outcome> Outcomes = new();
    private static string mode = "off";
    private static readonly Dictionary<DateTime,(State Regime,double Equity)> BtcAdmission = new();
    private static readonly Dictionary<State,(int Trades,double Mean)> BtcSettled = new();

    private sealed class Count
    {
        public int Seen, Admitted;
        public double FactorSum;
    }

    private sealed class Outcome
    {
        public int Baskets, Wins;
        public double Pnl;
    }

    internal static void Prepare(Data xau, Data eur, Data btc)
    {
        Histories["XAUUSD"] = Classify(xau.Rows);
        Histories["EURUSD"] = Classify(eur.Rows);
        Histories["BTCUSD"] = Classify(btc.Rows);
    }

    internal static void Configure(string value)
    {
        if (value is not ("off" or "rotation" or "defensive" or "drawdown" or "selective" or "settled-btc"))
            throw new ArgumentException("Unknown regime policy: " + value);
        mode = value;
        EntryFactors.Clear();
        Counts.Clear();
        Outcomes.Clear();
        BtcAdmission.Clear();
        BtcSettled.Clear();
    }

    private static List<Observation> Classify(Row[] rows)
    {
        var observations = new List<Observation>();
        var bucket = DateTime.MinValue;
        double close = 0, previous = 0, fast = 0, slow = 0, previousFast = 0, vol = 0;
        int samples = 0, bars = 0, repetitions = 0;
        var proposed = State.WarmingUp;

        foreach (var row in rows)
        {
            var current = new DateTime(row.At.Ticks / TimeSpan.TicksPerHour / 4 * 4 * TimeSpan.TicksPerHour,
                DateTimeKind.Utc);
            if (current != bucket)
            {
                if (samples >= 180)
                {
                    bars++;
                    double movement = previous > 0 ? Math.Abs(Math.Log(close / previous)) : 0;
                    fast = bars == 1 ? close : fast + 2d / 21 * (close - fast);
                    slow = bars == 1 ? close : slow + 2d / 81 * (close - slow);
                    double spread = (fast - slow) / close;
                    double threshold = Math.Max(0.0005, vol * 1.25);
                    State raw = State.WarmingUp;
                    if (bars >= 80)
                    {
                        if (vol > 0 && movement > 3.5 * vol)
                            raw = State.Shock;
                        else if (Math.Abs(spread) <= threshold)
                            raw = State.Range;
                        else if (spread > threshold && fast > previousFast)
                            raw = State.Uptrend;
                        else if (spread < -threshold && fast < previousFast)
                            raw = State.Downtrend;
                        else
                            raw = State.Transition;
                    }
                    repetitions = raw == proposed ? repetitions + 1 : 1;
                    proposed = raw;
                    State regime = repetitions >= 2 || raw is State.Shock or State.WarmingUp
                        ? raw : State.Transition;
                    observations.Add(new(bucket.AddHours(4), regime));
                    vol = bars == 2 ? movement : vol + (movement - vol) / 20;
                    previous = close;
                    previousFast = fast;
                }
                bucket = current;
                samples = 0;
            }
            close = row.Close;
            samples++;
        }

        return observations;
    }

    internal static State At(string symbol, DateTime at)
    {
        if (!Histories.TryGetValue(symbol, out var history)) return State.WarmingUp;
        int low = 0, high = history.Count;
        while (low < high)
        {
            int mid = low + (high - low) / 2;
            if (history[mid].ClosedAt <= at) low = mid + 1;
            else high = mid;
        }
        return low > 0 && at - history[low - 1].ClosedAt <= TimeSpan.FromHours(12)
            ? history[low - 1].Regime : State.WarmingUp;
    }

    internal static bool Admit(string symbol, DateTime at, int side, string family, bool alternative, double portfolioDrawdown = 0, double equity = 0)
    {
        if (mode == "off") return true;
        var state = At(symbol, at);
        bool aligned = (state == State.Uptrend && side == 1) || (state == State.Downtrend && side == -1);
        bool opposed = (state == State.Uptrend && side == -1) || (state == State.Downtrend && side == 1);
        double factor = state switch
        {
            State.Shock => mode == "defensive" ? .25 : .55,
            State.Transition => mode == "defensive" ? .55 : .8,
            State.Range => mode == "defensive" ? .7 : .9,
            State.WarmingUp => mode == "defensive" ? .6 : .85,
            _ => opposed ? (mode == "defensive" ? .5 : .8) : 1
        };
        if (alternative && !aligned) factor = 0;
        if (mode == "defensive" && opposed && symbol == "BTCUSD") factor = 0;
        if (mode == "selective" && ((symbol == "XAUUSD" && state == State.Range)
            || (symbol == "BTCUSD" && state == State.Uptrend))) factor *= .5;
        if (mode is "drawdown" or "settled-btc")
        {
            factor *= portfolioDrawdown switch
            {
                >= .50 => .2,
                >= .45 => .4,
                >= .35 => .65,
                >= .25 => .85,
                _ => 1
            };
        }
        if (mode == "settled-btc" && symbol == "BTCUSD")
        {
            if (BtcSettled.TryGetValue(state, out var observed) && observed.Trades >= 5 && observed.Mean < -.001)
                factor *= .35;
            if (factor > 0 && equity > 0) BtcAdmission[at] = (state,equity);
        }
        EntryFactors[symbol] = factor;
        var key = (symbol, state, family);
        if (!Counts.TryGetValue(key, out var count)) Counts[key] = count = new();
        count.Seen++;
        if (factor <= 0) return false;
        count.Admitted++;
        count.FactorSum += factor;
        return true;
    }

    internal static double SeedFactor(string symbol, DateTime at, int side, int family)
    {
        var regime = At(symbol, at);
        if (regime == State.Range) return family == 1 ? .8 : 0;
        if (regime == State.Transition) return family == 2 ? .65 : 0;
        if (regime == State.Uptrend && side == 1 || regime == State.Downtrend && side == -1)
            return family != 1 ? 1 : 0;
        return 0;
    }

    internal static double Factor(string symbol) => EntryFactors.GetValueOrDefault(symbol, 1);

    internal static void Record(Trade trade)
    {
        if (mode == "off") return;
        if (mode == "settled-btc" && trade.Symbol == "BTCUSD" && BtcAdmission.Remove(trade.Entry,out var admission))
        {
            var prior = BtcSettled.GetValueOrDefault(admission.Regime);
            var outcomeR = Math.Clamp(trade.Pnl/admission.Equity,-.20,.20);
            BtcSettled[admission.Regime] = (prior.Trades+1,prior.Trades==0?outcomeR:prior.Mean+.15*(outcomeR-prior.Mean));
        }
        var key = (trade.Symbol, At(trade.Symbol, trade.Entry), trade.Origin);
        if (!Outcomes.TryGetValue(key, out var outcome)) Outcomes[key] = outcome = new();
        outcome.Baskets++;
        outcome.Wins += trade.Pnl > 0 ? 1 : 0;
        outcome.Pnl += trade.Pnl;
    }

    internal static object Audit() => new
    {
        Mode = mode,
        SettledBtcReturns = BtcSettled.Select(p=>new { Regime=p.Key.ToString(), p.Value.Trades, p.Value.Mean }),
        Decisions = Counts.Select(p => new { p.Key.Symbol, Regime = p.Key.Regime.ToString(),
            p.Key.Family, p.Value.Seen, p.Value.Admitted, p.Value.FactorSum }),
        Outcomes = Outcomes.Select(p => new { p.Key.Symbol, Regime = p.Key.Regime.ToString(),
            p.Key.Family, p.Value.Baskets, p.Value.Wins, p.Value.Pnl })
    };

    internal static void SelfTest()
    {
        var start = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        var rows = Enumerable.Range(0, 240 * 86 + 1).Select(i =>
        {
            double price = 100 + i * .001;
            return new Row(start.AddMinutes(i), price, price, price, price, 0, 0, true, true);
        }).ToArray();
        var at = start.AddHours(4 * 84);
        Histories["XAUUSD"] = Classify(rows);
        var before = At("XAUUSD", at);
        for (int i = 240 * 84; i < rows.Length; i++) rows[i] = rows[i] with { Close = 1 };
        Histories["XAUUSD"] = Classify(rows);
        if (before != State.Uptrend || At("XAUUSD", at) != before)
            throw new Exception("REGIME_USES_UNCLOSED_BAR");
        if (SeedFactor("XAUUSD", at, 1, 0) != 1 || SeedFactor("XAUUSD", at, -1, 0) != 0)
            throw new Exception("SEED_REGIME_SELECTION");
        Configure("defensive");
        if (Admit("XAUUSD", at, -1, "alternative", true)
            || !Admit("XAUUSD", at, 1, "alternative", true) || Factor("XAUUSD") != 1)
            throw new Exception("REGIME_ADMISSION");
        Configure("drawdown");
        if (!Admit("XAUUSD", at, 1, "alternative", true, .46) || Factor("XAUUSD") != .4)
            throw new Exception("DRAWDOWN_THROTTLE_NOT_APPLIED");
        Histories["BTCUSD"] = Histories["XAUUSD"];
        Configure("settled-btc");
        for (int i=0;i<5;i++)
        {
            var entry=at.AddMinutes(i*10);
            if (!Admit("BTCUSD",entry,1,"test",false,0,100) || Factor("BTCUSD")!=1)
                throw new Exception("BTC_SIZING_BEFORE_MINIMUM_SETTLED_SAMPLE");
            Record(new Trade(entry,entry.AddMinutes(1),"BTCUSD",-2,98,1,100,1,"test"));
        }
        if (!Admit("BTCUSD",at.AddMinutes(50),1,"test",false,0,100) || Factor("BTCUSD")!=.35)
            throw new Exception("BTC_SIZING_IGNORED_SETTLED_EXPECTANCY");
        Configure("off");
        if (!Admit("XAUUSD", at, -1, "alternative", true) || Factor("XAUUSD") != 1)
            throw new Exception("REGIME_NEUTRAL_NOT_IDENTICAL");
        Console.WriteLine("PASS regime replay: closed H4, future mutation, admission, neutral parity");
    }
}
