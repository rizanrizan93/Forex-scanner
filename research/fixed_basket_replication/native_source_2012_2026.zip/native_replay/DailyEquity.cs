internal sealed class DailyEquity
{
    internal record Block(DateTime Day, double Start, double End, double High, double Low, double Drawdown);
    private readonly List<Block> blocks = new();
    private DateTime day;
    private double start = 100, last = 100, high = 100, low = 100, drawdown;

    internal void Observe(DateTime at, double equity)
    {
        DateTime date = at.Date;
        if (date != day)
        {
            if (day != default) Commit();
            day = date;
            start = last;
            high = last;
            low = last;
            drawdown = 0;
        }
        high = Math.Max(high, equity);
        low = Math.Min(low, equity);
        if (high > 0) drawdown = Math.Max(drawdown, 1 - equity / high);
        last = equity;
    }

    private void Commit() => blocks.Add(new(day, start, last, high, low, drawdown));

    internal IReadOnlyList<Block> Finish()
    {
        if (day != default) Commit();
        return blocks;
    }
}
