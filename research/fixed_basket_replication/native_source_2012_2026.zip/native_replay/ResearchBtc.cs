using Rizan.Portfolio;
using System.Text.Json;
static class ResearchBtc {
 public static Dictionary<DateTime,BtcSignal> Attach(Data data,Dictionary<DateTime,BtcSignal> primary,string output,bool export){
  var q=BtcCore.Aggregate(data.Rows.Select(r=>new BtcBar(r.At,r.Open,r.High,r.Low,r.Close)).ToList(),240);
  int before=primary.Count;EntryFamilies.MergeBtc(primary,q);
  Console.WriteLine("NATIVE_SOURCE_BTC_TAPE primary="+before+" total="+primary.Count);
  return primary;
 }
 public static Dictionary<DateTime,BtcSignal> Compression(Data d){
  var rows=d.Rows.Select(r=>new BtcBar(r.At,r.Open,r.High,r.Low,r.Close)).ToList();
  var h=EntryFamilies.Features(BtcCore.Aggregate(rows,60));var q=EntryFamilies.Features(BtcCore.Aggregate(rows,240));
  var result=new Dictionary<DateTime,BtcSignal>();int j=-1;
  for(int i=100;i<h.Count;i++){
   var f=h[i];var b=f.Bar;var at=b.At.AddHours(1);while(j+1<q.Count&&q[j+1].Bar.At.AddHours(4)<=at)j++;
   if(at.Year<2019||at.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday||j<100||!EntryFamilies.Complete(h,i,16,60))continue;
   var v=q[j];if(v.Bar.Count<192||at-v.Bar.At.AddHours(4)>TimeSpan.FromHours(4)||v.Bar.Close<=v.E80||v.E20<=v.E80||v.Efficiency<.2||!double.IsFinite(v.Efficiency))continue;
   double high=double.NegativeInfinity,range=0;
   for(int k=i-16;k<i;k++)high=Math.Max(high,h[k].Bar.High);
   for(int k=i-4;k<i;k++)range+=h[k].Bar.High-h[k].Bar.Low;
   if(f.Atr<=0||range/4>=h[i-1].Atr*.7||b.Close<=high+.1*f.Atr||b.Close<=b.Open||b.Close-b.Open>2.5*f.Atr||f.Rsi<45||f.Rsi>75)continue;
   result[at]=new(at,1,f.Atr,b.Close,EntryFamilies.BtcBullCompress);
  }
  return result;
 }
 public static Dictionary<DateTime,BtcSignal> MergeCompression(Dictionary<DateTime,BtcSignal> core,Dictionary<DateTime,BtcSignal> added){
  var r=new Dictionary<DateTime,BtcSignal>(core);foreach(var p in added)r.TryAdd(p.Key,p.Value);return r;
 }
}
