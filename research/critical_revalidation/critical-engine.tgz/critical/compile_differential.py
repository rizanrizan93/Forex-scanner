from pathlib import Path
import subprocess,json,sys
r=Path(__file__).resolve().parent;old=r.parent/'revalidation';out=r/'differential';out.mkdir(exist_ok=True);sdk=Path('/tmp/rizan-dotnet8')
s=(r/'engine/TickReplay.cs').read_text();s=s[s.index('record Config('):];(out/'TickClasses.cs').write_text('using System.Globalization;using System.Threading.Tasks;using System.Reflection;using System.Text.Json;using System.IO.Compression;using cAlgo.API;using Rizan.Portfolio;using X=Rizan.Portfolio.Xau;using E=Rizan.Portfolio.Eur;\n'+s)
refs=next((sdk/'packs/Microsoft.NETCore.App.Ref').glob('*/ref/net8.0'));csc=next((sdk/'sdk').glob('*/Roslyn/bincore/csc.dll'))
a=['-nologo','-target:exe','-langversion:latest','-nullable:enable','-define:REPLAY','-out:'+str(out/'Diff.dll')]+['-r:'+str(f) for f in refs.glob('*.dll')]+[str(p) for p in (old/'source').rglob('*.cs')]+[str(old/'tests/Global.cs'),str(r/'engine/ApiStubs.cs'),str(r/'engine/SourceTape.cs'),str(out/'TickClasses.cs'),str(r/'ExecutionDifferential.cs')]
(out/'build.rsp').write_text('\n'.join(a));subprocess.run([str(sdk/'dotnet'),str(csc),'@'+str(out/'build.rsp')],check=True,stdout=(out/'build.log').open('w'))
(out/'Diff.runtimeconfig.json').write_text(json.dumps({'runtimeOptions':{'tfm':'net8.0','framework':{'name':'Microsoft.NETCore.App','version':'8.0.0'}}}))
subprocess.run([str(sdk/'dotnet'),str(out/'Diff.dll'),str(old),str(out)],check=True,stdout=(out/'run.log').open('w'),stderr=(out/'error.log').open('w'))
