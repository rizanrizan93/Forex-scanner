from pathlib import Path
import os,json,subprocess,hashlib,shutil
r=Path(__file__).resolve().parent;src=r/'original/RIZAN_REPLAY_SETTLEMENT_2016_2026_20261017';out=r/'old_m1_controls';out.mkdir(exist_ok=True)
base=(src/'broker_replay/Replay.cs').read_text()
# Adapter-only controls: source files and strategy parameters remain unchanged.
base=base.replace('var xtape=TapeCache.LoadOrBuild(Path.Combine(Path.GetDirectoryName(args[2])!,"../xau-tape.json"),true,()=>Data.XauTape(xdata));GC.Collect();var etape=TapeCache.LoadOrBuild(Path.Combine(Path.GetDirectoryName(args[2])!,"../eur-tape.json"),false,()=>Data.EurTape(edata));','var xtape=Data.XauTape(xdata);GC.Collect();var etape=Data.EurTape(edata);')
old='var scenarios=new[]{new Scenario("DIAGNOSTIC_FLAGS_SEED0",200,1,2,true,20.75,true,true,false,maxYear),new Scenario("DIAGNOSTIC_FLAGS_SEED1",200,1,2,false,20.75,true,true,false,maxYear),new Scenario("STRICT_NO_MACRO",200,1,2,true,20.75,true,true,false,maxYear)};'
new='var scenarios=new[]{new Scenario("OLD_M1_IDEAL_0S",200,1,0,true,20.75,true,true,false,maxYear),new Scenario("OLD_M1_MODEL_2S",200,1,2,true,20.75,true,true,false,maxYear)};'
assert old in base;base=base.replace(old,new).replace('for(int step=0;step<2;step++)','for(int step=0;step<(int)cfg.Delay;step++)').replace('BrokerEntryDelaySeconds=2,','BrokerEntryDelaySeconds=cfg.Delay,').replace('Ledger=trades,Errors=errors','Ledger=trades,Positions=host.History,OrderEvents=host.OrderEvents,Errors=errors')
base=base.replace('if(at.Year>maxYear)break;rows.Add','if(at>=new DateTime(2026,4,1,0,0,0,DateTimeKind.Utc))break;if(at.Year<2019)continue;rows.Add')
(out/'Replay.cs').write_text(base);stub=(src/'broker_replay/ApiStubs.cs').read_text().replace('public int Requests,Closes;','public List<object> OrderEvents=new();public int Requests,Closes;').replace('Positions.Add(pos);','OrderEvents.Add(new{At=Server.TimeInUtc,Symbol=symbol,Side=side.ToString(),Volume=actualVolume,Status="FILLED",Entry=entry,Label=label});Positions.Add(pos);')
(out/'ApiStubs.cs').write_text(stub)
sdk=Path('/tmp/rizan-dotnet8');refs=next((sdk/'packs/Microsoft.NETCore.App.Ref').glob('*/ref/net8.0'));csc=next((sdk/'sdk').glob('*/Roslyn/bincore/csc.dll'))
build=['-nologo','-target:exe','-langversion:latest','-nullable:enable','-define:REPLAY','-out:'+str(out/'Replay.dll')]+['-r:'+str(p) for p in refs.glob('*.dll')]+[str(p) for p in (src/'source').rglob('*.cs')]+[str(src/'tests/Global.cs'),str(out/'ApiStubs.cs'),str(out/'Replay.cs')]
(out/'build.rsp').write_text('\n'.join(build));subprocess.run([str(sdk/'dotnet'),str(csc),'@'+str(out/'build.rsp')],check=True,stdout=(out/'build.log').open('w'))
(out/'Replay.runtimeconfig.json').write_text(json.dumps({'runtimeOptions':{'tfm':'net8.0','framework':{'name':'Microsoft.NETCore.App','version':'8.0.0'}}}))
# Original feed and frozen reconstructed flags; identical exact account period; no cached pre-2019 tape.
with (out/'run.log').open('w') as f,(out/'progress.log').open('w') as e:
 subprocess.run([str(sdk/'dotnet'),str(out/'Replay.dll'),str(src/'inputs/xau_2012_2026.csv'),str(src/'inputs/eur_2012_2026.csv'),str(out/'results.json'),'matrix','2019','2026'],check=True,stdout=f,stderr=e)
print('OLD_M1_DONE',out)
