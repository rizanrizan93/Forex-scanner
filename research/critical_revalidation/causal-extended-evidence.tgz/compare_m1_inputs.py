from pathlib import Path
import pandas as pd,numpy as np,json
r=Path(__file__).resolve().parent;old=r/'original/RIZAN_REPLAY_SETTLEMENT_2016_2026_20261017/inputs';rows=[]
for sym,f in [('XAUUSD','xau_2012_2026.csv'),('EURUSD','eur_2012_2026.csv')]:
 cols=['timestamp','open','high','low','close'];a=pd.read_csv(old/f,usecols=cols);b=pd.read_csv(r.parent/'revalidation/data_audit'/f'{sym}_m1.csv',usecols=cols)
 for q in [a,b]:q['timestamp']=pd.to_datetime(q.timestamp,utc=True)
 lo=pd.Timestamp('2019-01-01T00:00Z');hi=pd.Timestamp('2026-04-01T00:00Z');a=a[(a.timestamp>=lo)&(a.timestamp<hi)].set_index('timestamp');b=b[(b.timestamp>=lo)&(b.timestamp<hi)].set_index('timestamp');common=a.index.intersection(b.index);diff=(a.loc[common]-b.loc[common]).abs();same=(diff<1e-9).all(axis=1)
 report={'symbol':sym,'old_m1_rows':len(a),'tick_m1_rows':len(b),'common_minutes':len(common),'old_only_minutes':len(a.index.difference(b.index)),'tick_only_minutes':len(b.index.difference(a.index)),'common_all_ohlc_equal_within_1e_9':int(same.sum()),'different_common_ohlc':int((~same).sum()),'absolute_price_difference':{col:{'p50':float(diff[col].quantile(.5)),'p95':float(diff[col].quantile(.95)),'max':float(diff[col].max())}for col in diff.columns},'years':{str(y):{'common_minutes':int((common.year==y).sum()),'different_ohlc':int((~same[common.year==y]).sum())}for y in range(2019,2027)}};rows.append(report);print(json.dumps(report),flush=True)
json.dump(rows,open(r/'M1_FEED_COMPARISON.json','w'),indent=2)
