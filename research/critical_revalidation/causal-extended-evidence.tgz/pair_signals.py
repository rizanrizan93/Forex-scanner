from pathlib import Path
import json,csv,gzip,bisect
r=Path(__file__).resolve().parent;summary=[];pairs=[]
for symbol in ['XAUUSD','EURUSD']:
 a=json.load(open(r/'old_signal_export'/f'{symbol}_OLD_M1_SIGNALS.json'));b=json.load(open(r/'differential'/f'{symbol}_SIGNALS.json'))
 key=lambda p:(p['At'],p['Signal']['Side'])
 old={key(p):p for p in a};new={key(p):p for p in b};common=old.keys()&new.keys();equalgeom=0
 for k in sorted(old.keys()|new.keys()):
  x=old.get(k);y=new.get(k);equal=bool(x and y and all(abs(x['Signal'][f]-y['Signal'][f])<1e-9 for f in ['Distance','Atr','Anchor']));equalgeom+=int(equal)
  pairs.append({'symbol':symbol,'at':k[0],'side':k[1],'old_present':x is not None,'tick_candle_present':y is not None,'geometry_equal':equal,'old_atr':x['Signal']['Atr']if x else None,'tick_atr':y['Signal']['Atr']if y else None,'old_anchor':x['Signal']['Anchor']if x else None,'tick_anchor':y['Signal']['Anchor']if y else None,'old_distance':x['Signal']['Distance']if x else None,'tick_distance':y['Signal']['Distance']if y else None,'old_fast':x['Fast']if x else None,'tick_fast':y['Fast']if y else None,'old_slow':x['Slow']if x else None,'tick_slow':y['Slow']if y else None})
 summary.append({'symbol':symbol,'old_raw_signals':len(old),'tick_derived_raw_signals':len(new),'same_timestamp_and_side':len(common),'old_only':len(old.keys()-new.keys()),'tick_only':len(new.keys()-old.keys()),'same_geometry':equalgeom,'definition':'Raw frozen technical candidates before macro, real position, risk, margin and cooldown gates; not executed basket counts. Both cold-start2019 and stop2026-03-31.'})
with(r/'PAIRED_OLD_M1_VS_TICK_SIGNALS.csv').open('w')as f:w=csv.DictWriter(f,fieldnames=pairs[0]);w.writeheader();w.writerows(pairs)
json.dump(summary,open(r/'SIGNAL_FEED_DIFFERENCES.json','w'),indent=2);print(json.dumps(summary,indent=2))
