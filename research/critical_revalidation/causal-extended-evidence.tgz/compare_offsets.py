from pathlib import Path
import pandas as pd,numpy as np,json
r=Path(__file__).resolve().parent;old=r/'original/RIZAN_REPLAY_SETTLEMENT_2016_2026_20261017/inputs';rows=[]
for sym,f in [('XAUUSD','xau_2012_2026.csv'),('EURUSD','eur_2012_2026.csv')]:
 cols=['timestamp','open','high','low','close'];a=pd.read_csv(old/f,usecols=cols);b=pd.read_csv(r.parent/'revalidation/data_audit'/f'{sym}_m1.csv',usecols=cols)
 for q in[a,b]:q['timestamp']=pd.to_datetime(q.timestamp,utc=True)
 a=a[(a.timestamp>=pd.Timestamp('2019-01-01T00:00Z'))&(a.timestamp<pd.Timestamp('2026-04-01T00:00Z'))].set_index('timestamp');b=b.set_index('timestamp');aa=a[['open','high','low','close']].to_numpy();dst=np.array([bool(x.dst())for x in a.index.tz_convert('Europe/London').to_pydatetime()])
 for hours in [-2,-1,0,1,2]:
  target=a.index+pd.Timedelta(hours=hours);idx=b.index.get_indexer(target);valid=idx>=0;eq=np.zeros(len(a),bool);eq[valid]=(np.abs(aa[valid]-b.iloc[idx[valid]][['open','high','low','close']].to_numpy())<1e-9).all(axis=1)
  rows.append({'symbol':sym,'new_timestamp_minus_old_timestamp_hours':hours,'old_rows':len(a),'overlapping_rows':int(valid.sum()),'all_ohlc_exact_matches':int(eq.sum()),'matches_during_London_DST':int((eq&dst).sum()),'matches_outside_London_DST':int((eq&~dst).sum()),'London_DST_rows':int(dst.sum()),'not_DST_rows':int((~dst).sum())})
 print(sym,rows[-5:],flush=True)
json.dump(rows,open(r/'TIMESTAMP_OFFSET_DIFFERENTIAL.json','w'),indent=2)
