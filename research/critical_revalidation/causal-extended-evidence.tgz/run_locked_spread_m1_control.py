from pathlib import Path
import pandas as pd,subprocess,json
r=Path(__file__).resolve().parent;src=r/'original/RIZAN_REPLAY_SETTLEMENT_2016_2026_20261017';out=r/'tick_m1_locked_spread_controls';out.mkdir(exist_ok=True)
a=pd.read_csv(r/'tick_m1_controls/xau_tick_derived_m1.csv');a['timestamp']=pd.to_datetime(a.timestamp,utc=True)
b=pd.read_csv(src/'inputs/xau_2012_2026.csv',usecols=['timestamp','spread']);b['timestamp']=pd.to_datetime(b.timestamp,utc=True);b=b.sort_values('timestamp');b=b.rename(columns={'timestamp':'spread_model_at','spread':'original_spread'})
c=pd.merge_asof(a,b,left_on='timestamp',right_on='spread_model_at',direction='backward');assert c.original_spread.notna().all();age=(c.timestamp-c.spread_model_at).dt.total_seconds();audit={'scope':'Tick-derived candles unchanged, original archived XAU spread series held fixed/asof; EUR keeps original engine fixed .00001 spread; no future spread timestamp. Synthetic OHLC diagnostic only.','rows':len(c),'exact_timestamp_spread_matches':int((age==0).sum()),'carry_forward_spread_rows':int((age>0).sum()),'maximum_model_spread_age_seconds':float(age.max())};json.dump(audit,open(out/'SPREAD_HOLD_POLICY.json','w'),indent=2);c['spread']=c.original_spread;c=c.drop(columns=['original_spread','spread_model_at']);c.to_csv(out/'xau_tick_m1_original_spread.csv',index=False)
cmd=['/tmp/rizan-dotnet8/dotnet',str(r/'old_m1_controls/Replay.dll'),str(out/'xau_tick_m1_original_spread.csv'),str(r.parent/'revalidation/data_audit/EURUSD_m1.csv'),str(out/'results.json'),'matrix','2019','2026']
with(out/'run.log').open('w')as f,(out/'progress.log').open('w')as e:subprocess.run(cmd,check=True,stdout=f,stderr=e)
print('TICK_CANDLES_LOCKED_OLD_SPREAD_OHLC_DONE')
