from pathlib import Path
import json,urllib.request,hashlib
import numpy as np,pandas as pd,pyarrow.parquet as pq
r=Path(__file__).resolve().parent;root=r/'final-review';audit=json.load(open(r/'STALE_EXIT_MINUTE_AUDIT.json'));rows=audit['candidates'];out=r/'stale_exit_sensitivity';out.mkdir(exist_ok=True);checks={x['file']:x['sha256']for x in json.load(open('revalidation/data_audit/data_quality.json'))['files']};history={}
for p in(root/'patched_results').glob('*.json'):
 d=json.load(open(p))
 if'Config'in d:history[d['Config']['Name']]={p['Label']:p for p in d['Ledger']}
provenance=[]
for month in sorted({x['exit'][:7]for x in rows}):
 name=f'XAUUSD_{month}.parquet';p=out/name;u=f'https://huggingface.co/datasets/Henrik404/dukascopy-ticks/resolve/main/data/XAUUSD/{name}?download=true'
 with urllib.request.urlopen(u,timeout=120)as response,p.open('wb')as f:
  while b:=response.read(1048576):f.write(b)
 sha=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();assert sha==checks[name]
 df=pq.read_table(p,columns=['timestamp','bid','ask']).to_pandas();ts=pd.to_datetime(df.timestamp,utc=True).astype('datetime64[ns, UTC]').astype('int64').to_numpy()
 for q in rows:
  if not q['exit'].startswith(month):continue
  h=history[q['scenario']][q['label']];j=np.searchsorted(ts,pd.Timestamp(q['exit']).value,side='left');assert j<len(ts)
  side=1 if h['TradeType']==0 else-1;cost={'C_COST1_5_ARCHIVED_FLAGS':1.5,'C_COST2_ARCHIVED_FLAGS':2}.get(q['scenario'],1);slip=.05*cost;fee=.03*cost;quote=(float(df.bid.iloc[j])if side==1 else float(df.ask.iloc[j]))/1000;newexit=quote-side*slip;hyp=side*h['VolumeInUnits']*(newexit-h['EntryPrice'])-2*h['VolumeInUnits']*fee
  q.update({'first_subsequent_actual_quote_utc':str(pd.Timestamp(int(ts[j]),unit='ns',tz='UTC')),'first_subsequent_bid':float(df.bid.iloc[j])/1000,'first_subsequent_ask':float(df.ask.iloc[j])/1000,'volume':h['VolumeInUnits'],'original_exit_price':h['ExitPrice'],'counterfactual_fresh_quote_exit_price':newexit,'counterfactual_position_net_pnl_no_state_replay':hyp,'pnl_delta_no_compounding':hyp-h['NetProfit']})
 provenance.append({'file':name,'sha256':sha,'point':1000});p.unlink();print('VERIFIED_NEXT_QUOTE',month,flush=True)
summary={}
for name in sorted({x['scenario']for x in rows}):
 q=[x for x in rows if x['scenario']==name];summary[name]={'positions':len(q),'original_position_net_pnl':sum(x['pnl']for x in q),'fresh_next_quote_counterfactual_pnl':sum(x['counterfactual_position_net_pnl_no_state_replay']for x in q),'pnl_delta_fixed_volume_not_equity':sum(x['pnl_delta_no_compounding']for x in q)}
json.dump({'status':'DIAGNOSTIC_ONLY_EXECUTION_NOT_VALIDATED','method':'Reprice only flagged actual positions at first real subsequent Dukascopy tick; volume and other positions held fixed. NO interpolation. NOT a replay of frozen strategy. Does not re-evaluate intervening SL/TP, swaps, source quarantine/recovery, margin or compounding.','source_files':provenance,'summary':summary,'positions':rows},open(out/'STALE_EXIT_FRESH_TICK_SENSITIVITY.json','w'),indent=2);print(json.dumps(summary,indent=2))
