from pathlib import Path
import pandas as pd,numpy as np,zipfile,io,json,hashlib
from pandas.tseries.offsets import CustomBusinessDay
from pandas.tseries.holiday import USFederalHolidayCalendar
import argparse
a=argparse.ArgumentParser();a.add_argument('raw_evidence_zip');a.add_argument('corrected_2026_zip');a.add_argument('output_csv');args=a.parse_args()
z=zipfile.ZipFile(args.corrected_2026_zip);o=zipfile.ZipFile(args.raw_evidence_zip)
frames=[pd.read_csv(o.open(f'extracted/RAW_XAU_EUR_REPLAY_EVIDENCE/data/XAUUSD/data/xau-{y}.csv'),index_col=0,parse_dates=True) for y in range(2016,2026)];frames.append(pd.read_csv(io.BytesIO(z.read('xau_2026.csv')),index_col=0,parse_dates=True));raw=pd.concat(frames);raw.index=pd.to_datetime(raw.index,utc=True);raw=raw[~raw.index.duplicated(keep='first')].sort_index();raw=raw[raw.index<=pd.Timestamp('2026-10-09T21:58:00Z')];ts=raw.index.asi8;M=60_000_000_000
oldcal=pd.read_csv(o.open('extracted/RAW_XAU_EUR_REPLAY_EVIDENCE/data/XAUUSD/data/events_2016_2025.csv'));newcal=pd.read_csv(io.BytesIO(z.read('calendar_2026.csv')));cal=pd.concat([oldcal,newcal]);et=np.sort(pd.to_datetime(cal.timestamp_utc,utc=True,format="mixed").astype('int64').unique());hour=(ts%(1440*M))/(60*M);prior=(raw.high-raw.low).shift(1);normal=prior.rolling(48,min_periods=12).mean();shock=(prior>4*normal).fillna(False).to_numpy();spread=np.where(hour<6,.35,np.where(hour>=15,.40,.25))+.1*shock;near=np.zeros(len(ts),bool)
for t in et:near[np.searchsorted(ts,t-5*M):np.searchsorted(ts,t+30*M)]=True
raw['spread']=np.maximum(.11,spread+.25*near-.14);ny=raw.index.tz_convert('America/New_York');dates=ny.normalize();days=pd.date_range(dates.min()-pd.Timedelta(days=1),dates.max()+pd.Timedelta(days=1),freq='D');w=np.where(days.weekday==2,3,np.where(days.weekday<5,1,0));cum=np.cumsum(w);raw['roll']=np.where(ny.hour>=17,dates.map(pd.Series(cum,index=days)),dates.map(pd.Series(cum-w,index=days))).astype(np.int64)
j=np.searchsorted(et,ts-30*M);news=(j==len(et))|(et[np.minimum(j,len(et)-1)]>ts+495*M);macro=pd.read_csv(io.BytesIO(z.read('macro_daily.csv')),parse_dates=['observation_date']);bd=CustomBusinessDay(calendar=USFederalHolidayCalendar())
for series,side,col in [('DFII10',1,'buy_ok'),('DGS10',-1,'sell_ok')]:
 q=macro[['observation_date',series]].dropna();av=pd.DatetimeIndex(q.observation_date.map(lambda x:x+2*bd)).tz_localize('America/New_York').tz_convert('UTC').asi8;de=q[series].diff().to_numpy();ix=np.searchsorted(av,ts,side='right')-1;k=np.maximum(ix,0);raw[col]=((ix>=0)&(ts-av[k]<=7*1440*M)&np.isfinite(de[k])&(side*de[k]<=0)&news).astype(int)
assert len(raw)==3824781,len(raw)
raw.to_csv(args.output_csv,index_label='timestamp')
assert hashlib.sha256(Path(args.output_csv).read_bytes()).hexdigest()=='799b2c0828ab6f1f58923382f15c1b3c313bebada252f20e7235e62398a6d17a'
print('XAU_COMPLETE',len(raw))
