from pathlib import Path
import pandas as pd,json,subprocess,gzip
r=Path(__file__).resolve().parent;src=r/'original/RIZAN_REPLAY_SETTLEMENT_2016_2026_20261017';out=r/'tick_m1_controls';out.mkdir(exist_ok=True)
x=pd.read_csv(r.parent/'revalidation/data_audit/XAUUSD_m1.csv');x['timestamp']=pd.to_datetime(x.timestamp,utc=True)
with gzip.open(r.parent/'revalidation/archived_macro_flags.json.gz','rt')as f:g=json.load(f)
g=pd.DataFrame(g,columns=['timestamp','buy','sell']);g['timestamp']=pd.to_datetime(g.timestamp,utc=True)
a=pd.merge_asof(x,g,on='timestamp',direction='backward');a['buy_ok']=a.buy.fillna(0).astype(int);a['sell_ok']=a.sell.fillna(0).astype(int);a=a.drop(columns=['buy','sell']);a.to_csv(out/'xau_tick_derived_m1.csv',index=False)
cmd=['/tmp/rizan-dotnet8/dotnet',str(r/'old_m1_controls/Replay.dll'),str(out/'xau_tick_derived_m1.csv'),str(r.parent/'revalidation/data_audit/EURUSD_m1.csv'),str(out/'results.json'),'matrix','2019','2026']
with(out/'run.log').open('w')as f,(out/'progress.log').open('w')as e:subprocess.run(cmd,check=True,stdout=f,stderr=e)
print('TICK_DERIVED_OHLC_CONTROLS_DONE')
