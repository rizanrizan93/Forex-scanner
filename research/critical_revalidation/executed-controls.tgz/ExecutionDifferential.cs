using System.Reflection;
using System.Text.Json;
using cAlgo.API;
using Rizan.Portfolio;
using X=Rizan.Portfolio.Xau;
using E=Rizan.Portfolio.Eur;
var root=args[0];var output=args[1];Directory.CreateDirectory(output);
var xd=Data.Load(Path.Combine(root,"data_audit/XAUUSD_m1.csv"),true,2026);var ed=Data.Load(Path.Combine(root,"data_audit/EURUSD_m1.csv"),false,2026);var xt=Data.XauTape(xd);var et=Data.EurTape(ed);var gates=Gates.Read(Path.Combine(root,"archived_macro_flags.json.gz"));
var records=new List<object>();
foreach(bool xau in new[]{true,false})foreach(int delay in new[]{0,2})foreach(int sampleYear in new[]{2019,2021,2023,2025})foreach(double cash in new[]{100d,10000d}){
 var tape=xau?xt:et;var data=xau?xd:ed;
 var point=tape.Signals.First(k=>k.Key.Year==sampleYear&&(!xau||gates.Ok(k.Key,((X.Signal)k.Value.Signal).Side)));var at=point.Key;
 var sim=new TickSimulation(new Config("DIFF",delay,delay,1,xau,!xau,true),xd,ed,xt,et,gates);
 var h=(Host)typeof(TickSimulation).GetField("host",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(sim)!;
 var legs=(List<Leg>)typeof(TickSimulation).GetField("legs",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(sim)!;var leg=legs[0];
 var reference=new Host{EnableTrading=true,EnableXau=xau,EnableEur=!xau,ExpectedAccount="1237903",BridgeUrl="wss://example.invalid:25345",BridgeToken="offline-fixture"};reference.CreateEngines();var rl=new Leg(xau?reference.Xau!:reference.Eur!,xau,reference);
 foreach(var host in new[]{h,reference}){host.Account.Balance=host.Account.Equity=cash;var s=host.Symbols.GetSymbol(xau?"XAUUSD":"EURUSD");var i=data.Lower(at);var row=data.Rows[i];s.Bid=row.Open;s.Ask=row.Open+(xau?.25:.00012);host.Server.TimeInUtc=at;host.BeforeMarketFill=()=>{host.Server.TimeInUtc=host.Server.TimeInUtc.AddSeconds(delay);s.Bid+=xau?.01:.000001;s.Ask+=xau?.01:.000001;};}
 foreach(var l in new[]{leg,rl}){l.State.Eur.Fast=point.Value.Fast;l.State.Eur.Slow=point.Value.Slow;l.State.Eur.CursorUtc=at.AddMinutes(-1);l.Set("_lastBridgeAck",at);l.Set("_nextPing",at.AddHours(1));l.Set("_m1",Bars(data,at));}
 var snap=new X.ExternalSnapshot{ProducedUtc=at,CoverageFromUtc=at.AddMinutes(-30),CoverageToUtc=at.AddMinutes(495),ForexFactoryOk=true,BlsOk=true,Dfii10=new(){Delta=gates.Ok(at,1)?-1:1,AvailableUtc=at},Dgs10=new(){Delta=gates.Ok(at,-1)?1:-1,AvailableUtc=at}};
 if(xau)rl.Set("_snapshot",snap);
 var steps=new List<object>();
 for(int sec=0;sec<15;sec++){
  var now=at.AddSeconds(sec);if(h.Server.TimeInUtc>now||reference.Server.TimeInUtc>now)continue;
  typeof(TickSimulation).GetMethod("Time",BindingFlags.NonPublic|BindingFlags.Instance)!.Invoke(sim,new object[]{now.Ticks});
  typeof(TickSimulation).GetMethod("Cycle",BindingFlags.NonPublic|BindingFlags.Instance)!.Invoke(sim,new object[]{now});
  reference.Server.TimeInUtc=now;rl.Set("_lastBridgeAck",now);rl.Context.OnTimer();rl.Pump(reference.Server.TimeInUtc,delay);
  steps.Add(new{At=now,AdapterRequests=h.Requests,SourceRequests=reference.Requests,AdapterRevision=(long)leg.State.Revision,SourceRevision=(long)rl.State.Revision,AdapterPending=(string)leg.State.PendingLabel,SourcePending=(string)rl.State.PendingLabel});
 }
 records.Add(new{Symbol=xau?"XAUUSD":"EURUSD",Delay=delay,Signal=at,StartingBalance=cash,AdapterOrders=h.OrderEvents,SourceOrders=reference.OrderEvents,EqualOrders=JsonSerializer.Serialize(h.OrderEvents)==JsonSerializer.Serialize(reference.OrderEvents),AdapterBasket=JsonSerializer.SerializeToElement((object?)leg.Basket),SourceBasket=JsonSerializer.SerializeToElement((object?)rl.Basket),Steps=steps});
}
File.WriteAllText(Path.Combine(output,"ENTRY_CYCLE_DIFFERENTIAL.json"),JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
// Every tape signal is exported for paired causal analysis without selecting by profitability.
foreach(var tuple in new[]{("XAUUSD",xt),("EURUSD",et)}){
 var a=tuple.Item2.Signals.Select(p=>new{At=p.Key,Signal=JsonSerializer.SerializeToElement(p.Value.Signal,p.Value.Signal.GetType()),p.Value.Fast,p.Value.Slow});File.WriteAllText(Path.Combine(output,tuple.Item1+"_SIGNALS.json"),JsonSerializer.Serialize(a));}
Console.WriteLine("DIFFERENTIAL_DONE");
static Bars Bars(Data d,DateTime at){var b=new Bars();foreach(var x in d.Rows.TakeWhile(r=>r.At.AddMinutes(1)<=at)){b.OpenTimes.Add(x.At);b.OpenPrices.Add(x.Open);b.HighPrices.Add(x.High);b.LowPrices.Add(x.Low);b.ClosePrices.Add(x.Close);}return b;}
