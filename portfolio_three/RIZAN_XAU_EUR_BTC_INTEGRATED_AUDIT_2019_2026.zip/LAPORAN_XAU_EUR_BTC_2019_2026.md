# Integrasi XAU–EUR–BTC — hasil model 2019–2026

cBot tiga pair berhasil dibangun dengan SDK resmi cTrader 1.0.21. Source XAU/EUR dipertahankan; BTC memakai kandidat8500283 (profil7844/2269). Satu host/account/order API berbagi saldo, equity, margin, dan batas risiko. Tidak ada deployment/order live.

**Saldo awal $100, tanpa top-up; 1 Januari 2019–9 Oktober 2026 21:58 UTC.** Data BTC tersedia sampai15Okt, tetapi portofolio berhenti pada irisan data XAU/EUR. 2026 belum satu tahun penuh.

## Hasil aktual yang telah direkonsiliasi

| Kasus | Saldo akhir USD | Floating DD model | Balance DD | PF | Win rate | Basket XAU/EUR/BTC | BTC BUY/SELL |
|---|---:|---:|---:|---:|---:|---:|---:|
| THREE_PATH_A | 24,536,880.31 | 54.4809% | 50.9032% | 2.28250 | 47.08% | 289/178/132 | 65/67 |
| THREE_PATH_B | 24,801,270.16 | 52.4692% | 46.8901% | 2.14899 | 49.75% | 292/177/130 | 63/67 |
| XAU_EUR_CONTROL_A | 4,945,782.89 | 54.0846% | 51.1913% | 1.96035 | 43.89% | 298/185/0 | 0/0 |

Baseline dua jalur model melampaui$500.000 dengan DDjalur≤56%. **Belum dinyatakan lolos protokol DD konservatif seluruh OHLC M1 atau validasi tick broker/FULL_PARITY.** Dua jalur bukan batas semua urutan intramenit. Tidak ada optimasi parameter untuk integrasi ini.

Pada jalurA, kontrol XAU/EUR memakai account baru dan source/biaya/jalur yang sama dengan BTC dinonaktifkan. Perubahan saldo mencakup compounding dan persaingan margin; bukan penjumlahan hasil standalone. Semua skenario berakhir tanpa posisi terbuka dan tanpa close paksa akhir periode.

## Konfigurasi dan batas akun

- XAU/EUR entry/exit/layer/settlement:8 file strategi byte-identik dengan release Settlement1.1.1 yang checksum binary-nya cocok lampiran.
- BTC BUY: H4 displacement_follow, body>1.4ATR14 dan close>high bar sebelumnya, tren H4 close>EMA80 dan EMA20>EMA80; sesi entry00–08UTC. SL2ATR, TP12R, hold128jam, risk23%, margin95%.
- BTC SELL: H1 compression_break, meanrange4bar<0.7ATR sebelumnya dan close<low16bar−0.1ATR; tren H4 bearish; body≤2.5ATR, RSI≥25, rasioATR20bar [0.6,1.8]. SL1.5ATR, TP2R, hold8jam, risk18%, margin30%.
- Kedua arah: candle closed, next-open model dengan broker-delay2detik; chase≤0.5ATR, satu basketBTC, tanpa add/BE/trailing; min0.01BTC, max100BTC, native step/max broker dihormati.
- Gate entry gabungan: risiko20.75% dan margin50%; BTC model10×, XAU/EUR200×. Gate ini membatasi entry, **bukan** jaminan margin/risk persentase tidak naik ketika equity turun. Lihat max_observed_margin/open_risk di CSV.
- Sizing BTC diintegrasi dapat lebih kecil dari standalone karena cap bersama. Native memakai estimated margin broker dan floor margin10×; leverage broker tidak diubah. Konversi unitBTC memakai PipValue/PipSize, bukan menganggap lot sama denganBTC.
- Kirim order defaultOFF; checkpoint host dipisahkan; intent BTC yang status kirimnya tidak jelas memblokir recovery. Source BTC mencoba seed2019, fallback≥1000bar broker H1/H4 bila sejarah2019 tidak tersedia, dan mencatat seed aktual. Perbedaan feed/seed bisa mengubah sinyal.

## Ledger, biaya, dan kontribusi arah

FILL_LEDGER.csv mencatat gross PnL, entry commission, exit commission, swap/funding, net PnL, entry/exitprice dan waktu close setiap fill. BUY_SELL_CONTRIBUTIONS.csv memisahkan profit/rugi gross-net fill serta biaya per aset/arah. CASH_RECONCILIATION.json menghitung ulang net=gross−komisi−financing, saldo=$100+net, PFperbasket dan balanceDD dari cash-event trace. Residual maksimum di bawah$0.00001. Layering XAU/EUR ada pada add_stage_fills dan distinct_add_stages; BTC tidak layering.

| Jalur | BTC BUY net USD | BTC SELL net USD | XAU net USD | EUR net USD |
|---|---:|---:|---:|---:|
| THREE_PATH_A | 2,817,125.60 | 822,347.06 | 19,533,679.54 | 1,363,628.11 |
| THREE_PATH_B | 3,033,871.99 | 817,393.77 | 19,238,303.01 | 1,711,601.39 |

## Audit dan batas model

- Native .algo dibangun tanpa REPLAY melalui task resmi cTrader1.0.21, references.NET6.0.36 dan SDK8.0.426. Total1301 pemeriksaan: settlement171, portofolio827, timing121, BTC182. Termasuk158 sinyal yang cocok dengan C++ beku, causality, actual native-timer adapter fixture, busy signal, shared caps, foreign exposure, expiry dan uncertain recovery.
- Seluruh replay lengkap: ErrorCount0, tidak quarantine/accounting block; cash ledger lulus. Uji tidak menjamin semua perilaku broker bebas error.
- Source replay memakai broker tiruan dan dua lintasan OHLC independen posisi (seed timestamp). Tidak memakai rekaman tick broker. Ini **diagnostik M1**, bukan tick sintetis yang boleh diperlakukan sebagai data asli. BTC exit pada lintasan tersebut berbeda dari model standalone stop-first M1; hasil standalone tidak boleh dianggap identik.
- XAU macro berupa rekonstruksi flag historis, belum vintage point-in-time tersertifikasi. Missing-active-instrument minutes dicatat; ketika bar suatu instrumen tidak tersedia, quote terakhir instrumen itu dipertahankan. Ini keterbatasan data, bukan bar baru yang diimputasi.
- Model biaya: BTC spread5bp, fee5bp/sisi, slip1bp/sisi, funding3bp notional/hari kedua arah. XAU spreadCSV, slip$0.05/oz/sisi, fee$0.03/oz/sisi, swap$1/oz/roll (Rabu3×); EUR spread0.00001, slip0.00001/sisi, fee0.00003/unit/sisi, tanpa swap dalam harness. Tarif broker belum diverifikasi.
- **Stress biaya/delay/leverage portofolio gabungan belum dijalankan.** ACK2s/broker2s adalah asumsi baseline. Stress BTC standalone sebelumnya bukan stress portofolio gabungan. DD≤56% tidak diklaim pada kondisi biaya/delay lain.
- Replay source memakai cached signal kausal, adapter PrepareBasket/ProcessQueue/ManagePositions dan BTC Enter bersama gate host. Full lifecycle native selama8tahun belum direplay. Perubahan native history warmup hanya diuji fixture; tidak menjadi klaim full binary parity.
- Input EUR dalam paket lama terpotong; dipulihkan dari raw ZIP2016–2026 dan prefix asli2011–2015. Hasil tepat sama dengan SHA manifest. Lihat INPUT_RECOVERY.json. Percobaan lokal yang dihentikan/bermasalah tidak dipakai sebagai hasil final.

## Sumber dan reproduksi

Source commit: `441088c90d323c008af7016a3adabe24138fd183` pada branch `research/xau-eur-btc-integrated-2019-2026`. Build tools Actions: https://github.com/rizanrizan93/Forex-scanner/actions/runs/39345246182 . Workflow publikasi/audit akhir ditautkan pada jawaban pengiriman.

SHA inputBTC: `c217e367a22cab5f157d6d8a38828b9ada249f5a2d0657f20d204fee881c9504`; XAU: `3fda8011082e2691b6ebe1a8a4da5fff8e4bf0fc07baf57506b7894d95fc1808`; EUR: `3c74ac5ccaeeac64f44693bc6bd4406e9225a9ef61dbb5f80756530f050506ec`. Input penuh tidak digandakan dalam paket; gunakan arsip input yang checksum-nya cocok.

Build: `python build_native.py --sdk /path/to/sdk`; vendor cTrader.Automate1.0.21 dan net6ref6.0.36 ditempatkan seperti script. Compile replay: `python run_local.py /path/to/sdk replay`. Run: `BTC_INPUT=/path/BTCUSD_M1.csv dotnet replay/Replay.dll /path/xau.csv /path/eur.csv /path/results.json matrix 2019 2026`. Skenario0=A,1=B,2=kontrol. ReplayDebug.cs hanya menambah heartbeat, tidak mengubah strategi; source penuh dan diff disertakan.

Grafik memakai snapshotperjam; DD tabel memakai observasi model selama seluruh event aktif. ANNUAL.csv memakai saldo kronologis; MONTHLY.csv mengalokasikan net basket pada bulanclose sehingga dapat berbeda dari perubahan cashbulanan akibat biaya posisi terbuka. Hasil historis hasil optimasi bukan bukti performa masa depan.
