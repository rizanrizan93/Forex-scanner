from pathlib import Path
import json,csv,hashlib,gzip,shutil,zipfile,collections,datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent;out=root/'delivery';out.mkdir(exist_ok=True)
reports=[json.loads((root/'replay'/n).read_text())['Reports'][0] for n in ['path_a.json','path_b.json','control_a.json']]
metrics=[];contrib=[];annual=[];monthly=[];ledger=[];cashproof=[];layers=[]
def write(name,rows):
 if not rows:return
 with (out/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for r in reports:
 s=r['Summary'];case=s['cfg']['Name'];hist=r['BrokerHistory'];tr=r['Ledger'];assert s['ErrorCount']==0 and not s['AccountingBlock'] and not s['Quarantined'] and s['OpenPositions']==0
 err=max(abs(h['NetProfit']-(h['GrossProfit']+h['Commissions']+h['ExitCommission']+h['Swap'])) for h in hist)
 hpnl=sum(h['NetProfit'] for h in hist);balance=100+hpnl;balance_error=balance-s['EndingBalance'];assert abs(balance_error)<1e-5 and err<1e-7
 peak=100;dd=0
 for e in r['CashEvents']:peak=max(peak,e['Balance']);dd=max(dd,100*(peak-e['Balance'])/peak)
 assert abs(dd-s['MaxClosedDDPct'])<1e-8
 groups=collections.defaultdict(float)
 for h in hist:groups['|'.join(h['Label'].split('|')[:2])]+=h['NetProfit']
 assert len(groups)==len(tr)
 gains=sum(max(0,x) for x in groups.values());loss=-sum(min(0,x) for x in groups.values());pf=gains/loss;assert abs(pf-s['PF'])<1e-8
 wins=sum(x>0 for x in groups.values());layerfills=sum(len(h['Label'].split('|'))>2 and int(h['Label'].split('|')[2])>0 for h in hist)
 layerstages=len(set('|'.join(h['Label'].split('|')[:3]) for h in hist if len(h['Label'].split('|'))>2 and int(h['Label'].split('|')[2])>0))
 m={'case':case,'ending_balance':s['EndingBalance'],'ending_equity':s['EndingEquity'],'floating_dd_pct_path_model':s['MaxEquityDDPct'],'balance_dd_pct':dd,'pf':pf,'win_rate_pct':100*wins/len(tr),'baskets':len(tr),'xau':s['XauBaskets'],'eur':s['EurBaskets'],'btc':s['BtcBaskets'],'btc_buy':s['BtcBuys'],'btc_sell':s['BtcSells'],'native_fills':len(hist),'add_stage_fills':layerfills,'distinct_add_stages':layerstages,'runtime_errors':s['ErrorCount'],'max_observed_margin_pct':s['MaxObservedMarginPct'],'max_observed_open_risk_pct':s['MaxObservedOpenRiskPct'],'missing_active_instrument_minutes':s['MissingActiveInstrumentMinutes']};metrics.append(m)
 cashproof.append({'case':case,'gross_pnl':sum(h['GrossProfit'] for h in hist),'commission_entry':-sum(h['Commissions'] for h in hist),'commission_exit':-sum(h['ExitCommission'] for h in hist),'financing_swap':-sum(h['Swap'] for h in hist),'net_pnl':hpnl,'initial_capital':100,'ending_balance':s['EndingBalance'],'cash_residual':balance_error,'max_row_identity_error':err,'balance_dd_recomputed':dd,'pf_recomputed':pf,'open_positions':0,'extra_deposits':0})
 for symbol in ['XAUUSD','EURUSD','BTCUSD']:
  for side in [0,1]:
   h=[x for x in hist if x['SymbolName']==symbol and x['TradeType']==side]
   contrib.append({'case':case,'symbol':symbol,'side':'BUY' if side==0 else 'SELL','fills':len(h),'gross_profit':sum(x['GrossProfit'] for x in h),'gross_winning_net_fills':sum(max(0,x['NetProfit']) for x in h),'gross_losing_net_fills':sum(min(0,x['NetProfit']) for x in h),'entry_commission':-sum(x['Commissions'] for x in h),'exit_commission':-sum(x['ExitCommission'] for x in h),'financing_swap':-sum(x['Swap'] for x in h),'net_pnl':sum(x['NetProfit'] for x in h)})
 annual += [{'case':case,**x} for x in r['Annual']];monthly += [{'case':case,**x} for x in r['Monthly']]
 ledger += [{'case':case,**h} for h in hist]
 with gzip.open(out/(case+'_RAW_REPLAY.json.gz'),'wt') as f:json.dump(r,f,separators=(',',':'))
write('FINAL_METRICS.csv',metrics);write('BUY_SELL_CONTRIBUTIONS.csv',contrib);write('ANNUAL.csv',annual);write('MONTHLY.csv',monthly);write('FILL_LEDGER.csv',ledger)
(out/'CASH_RECONCILIATION.json').write_text(json.dumps(cashproof,indent=2))
fig,ax=plt.subplots(2,1,figsize=(12,7),sharex=True,gridspec_kw={'height_ratios':[2,1]})
for r in reports:
 c=r['Summary']['cfg']['Name'];rows=r['Curve'];t=[datetime.datetime.fromisoformat(x['At'].replace('Z','+00:00')) for x in rows];eq=[x['Equity'] for x in rows];dd=[100*(x['Peak']-x['Equity'])/x['Peak'] for x in rows]
 ax[0].plot(t,eq,label=c,lw=1);ax[1].plot(t,dd,lw=.8)
ax[0].set_yscale('log');ax[0].set_ylabel('Equity USD (log)');ax[1].set_ylabel('Floating DD %');ax[1].set_xlabel('UTC');ax[0].legend(fontsize=8);ax[0].set_title('Shared account, $100, no deposits; hourly snapshots of OHLC model')
for a in ax:a.grid(alpha=.2)
fig.tight_layout();fig.savefig(out/'EQUITY_DRAWDOWN.png',dpi=160);plt.close(fig)
status={'source_commit':'441088c90d323c008af7016a3adabe24138fd183','branch':'research/xau-eur-btc-integrated-2019-2026','initial_capital':100,'last_input_bar_utc':'2026-10-09T21:58:00Z','nominal_path_models_pass_500k_dd56':all(x['ending_balance']>=500000 and x['floating_dd_pct_path_model']<=56 for x in metrics[:2]),'strict_ohlc_bound_protocol_verified':False,'native_tick_parity':False,'portfolio_cost_stress_run':False,'tests':1301,'live_deployment':False,'metrics':metrics,'native_algo_sha256':hashlib.sha256((root/'native/RizanXauEurBtcPortfolio_RESEARCH_V1_2_0.algo').read_bytes()).hexdigest()}
(out/'STATUS.json').write_text(json.dumps(status,indent=2))
# Copy source, native build proof and all non-secret verification files.
for folder in ['source','audit']:
 dest=out/folder;dest.mkdir(exist_ok=True)
 for p in (root/folder).rglob('*'):
  if p.is_file() and p.suffix in ['.cs','.csproj','.json','.log','.diff'] and p.stat().st_size<200000:
   q=dest/p.relative_to(root/folder);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for name in ['PROTOCOL.md','run_local.py','build_native.py','BuildAlgo.cs','AssemblyInfo.cs','BTC_REFERENCE_SIGNALS.csv','finalize_portfolio.py']:shutil.copy2(root/name,out/name)
for n in ['SettlementTests','PortfolioTests','TimingTests']:
 d=out/'validation'/n;d.mkdir(parents=True,exist_ok=True)
 for p in (root/'validation'/n).iterdir():
  if p.suffix in ['.cs','.json','.log']:shutil.copy2(p,d/p.name)
for n in ['ApiStubs.cs','Replay.cs','ReplayDebug.cs','path_a_run.log','path_a_progress.log','path_b_run.log','path_b_progress.log','control_a_run.log','control_a_progress.log']:
 d=out/'replay';d.mkdir(exist_ok=True);shutil.copy2(root/'replay'/n,d/n)
(out/'tests').mkdir(exist_ok=True);shutil.copy2(root/'tests/Global.cs',out/'tests/Global.cs')
for n in ['compile.log','bundle.log','RizanXauEurPortfolio.algo.metadata']:
 d=out/'native';d.mkdir(exist_ok=True);shutil.copy2(root/'native'/n,d/n)
shutil.copy2(root/'native/RizanXauEurBtcPortfolio_RESEARCH_V1_2_0.algo',out/'RizanXauEurBtcPortfolio_RESEARCH_V1_2_0.algo')
report=['# Integrasi XAU–EUR–BTC — hasil model 2019–2026','', 'cBot tiga pair berhasil dibangun dengan SDK resmi cTrader 1.0.21. Source XAU/EUR dipertahankan; BTC memakai kandidat8500283 (profil7844/2269). Satu host/account/order API berbagi saldo, equity, margin, dan batas risiko. Tidak ada deployment/order live.','', '**Saldo awal $100, tanpa top-up; 1 Januari 2019–9 Oktober 2026 21:58 UTC.** Data BTC tersedia sampai15Okt, tetapi portofolio berhenti pada irisan data XAU/EUR. 2026 belum satu tahun penuh.','', '## Hasil aktual yang telah direkonsiliasi','', '| Kasus | Saldo akhir USD | Floating DD model | Balance DD | PF | Win rate | Basket XAU/EUR/BTC | BTC BUY/SELL |','|---|---:|---:|---:|---:|---:|---:|---:|']
for x in metrics:report.append(f"| {x['case']} | {x['ending_balance']:,.2f} | {x['floating_dd_pct_path_model']:.4f}% | {x['balance_dd_pct']:.4f}% | {x['pf']:.5f} | {x['win_rate_pct']:.2f}% | {x['xau']}/{x['eur']}/{x['btc']} | {x['btc_buy']}/{x['btc_sell']} |")
report += ['', 'Baseline dua jalur model melampaui$500.000 dengan DDjalur≤56%. **Belum dinyatakan lolos protokol DD konservatif seluruh OHLC M1 atau validasi tick broker/FULL_PARITY.** Dua jalur bukan batas semua urutan intramenit. Tidak ada optimasi parameter untuk integrasi ini.','', 'Pada jalurA, kontrol XAU/EUR memakai account baru dan source/biaya/jalur yang sama dengan BTC dinonaktifkan. Perubahan saldo mencakup compounding dan persaingan margin; bukan penjumlahan hasil standalone. Semua skenario berakhir tanpa posisi terbuka dan tanpa close paksa akhir periode.','', '## Konfigurasi dan batas akun','', '- XAU/EUR entry/exit/layer/settlement:8 file strategi byte-identik dengan release Settlement1.1.1 yang checksum binary-nya cocok lampiran.','- BTC BUY: H4 displacement_follow, body>1.4ATR14 dan close>high bar sebelumnya, tren H4 close>EMA80 dan EMA20>EMA80; sesi entry00–08UTC. SL2ATR, TP12R, hold128jam, risk23%, margin95%.','- BTC SELL: H1 compression_break, meanrange4bar<0.7ATR sebelumnya dan close<low16bar−0.1ATR; tren H4 bearish; body≤2.5ATR, RSI≥25, rasioATR20bar [0.6,1.8]. SL1.5ATR, TP2R, hold8jam, risk18%, margin30%.','- Kedua arah: candle closed, next-open model dengan broker-delay2detik; chase≤0.5ATR, satu basketBTC, tanpa add/BE/trailing; min0.01BTC, max100BTC, native step/max broker dihormati.','- Gate entry gabungan: risiko20.75% dan margin50%; BTC model10×, XAU/EUR200×. Gate ini membatasi entry, **bukan** jaminan margin/risk persentase tidak naik ketika equity turun. Lihat max_observed_margin/open_risk di CSV.','- Sizing BTC diintegrasi dapat lebih kecil dari standalone karena cap bersama. Native memakai estimated margin broker dan floor margin10×; leverage broker tidak diubah. Konversi unitBTC memakai PipValue/PipSize, bukan menganggap lot sama denganBTC.','- Kirim order defaultOFF; checkpoint host dipisahkan; intent BTC yang status kirimnya tidak jelas memblokir recovery. Source BTC mencoba seed2019, fallback≥1000bar broker H1/H4 bila sejarah2019 tidak tersedia, dan mencatat seed aktual. Perbedaan feed/seed bisa mengubah sinyal.','', '## Ledger, biaya, dan kontribusi arah','', 'FILL_LEDGER.csv mencatat gross PnL, entry commission, exit commission, swap/funding, net PnL, entry/exitprice dan waktu close setiap fill. BUY_SELL_CONTRIBUTIONS.csv memisahkan profit/rugi gross-net fill serta biaya per aset/arah. CASH_RECONCILIATION.json menghitung ulang net=gross−komisi−financing, saldo=$100+net, PFperbasket dan balanceDD dari cash-event trace. Residual maksimum di bawah$0.00001. Layering XAU/EUR ada pada add_stage_fills dan distinct_add_stages; BTC tidak layering.','', '| Jalur | BTC BUY net USD | BTC SELL net USD | XAU net USD | EUR net USD |','|---|---:|---:|---:|---:|']
for x in metrics[:2]:
 rows=[c for c in contrib if c['case']==x['case']];get=lambda sym,side=None:sum(c['net_pnl'] for c in rows if c['symbol']==sym and (side is None or c['side']==side));report.append(f"| {x['case']} | {get('BTCUSD','BUY'):,.2f} | {get('BTCUSD','SELL'):,.2f} | {get('XAUUSD'):,.2f} | {get('EURUSD'):,.2f} |")
report += ['', '## Audit dan batas model','', '- Native .algo dibangun tanpa REPLAY melalui task resmi cTrader1.0.21, references.NET6.0.36 dan SDK8.0.426. Total1301 pemeriksaan: settlement171, portofolio827, timing121, BTC182. Termasuk158 sinyal yang cocok dengan C++ beku, causality, actual native-timer adapter fixture, busy signal, shared caps, foreign exposure, expiry dan uncertain recovery.','- Seluruh replay lengkap: ErrorCount0, tidak quarantine/accounting block; cash ledger lulus. Uji tidak menjamin semua perilaku broker bebas error.','- Source replay memakai broker tiruan dan dua lintasan OHLC independen posisi (seed timestamp). Tidak memakai rekaman tick broker. Ini **diagnostik M1**, bukan tick sintetis yang boleh diperlakukan sebagai data asli. BTC exit pada lintasan tersebut berbeda dari model standalone stop-first M1; hasil standalone tidak boleh dianggap identik.','- XAU macro berupa rekonstruksi flag historis, belum vintage point-in-time tersertifikasi. Missing-active-instrument minutes dicatat; ketika bar suatu instrumen tidak tersedia, quote terakhir instrumen itu dipertahankan. Ini keterbatasan data, bukan bar baru yang diimputasi.','- Model biaya: BTC spread5bp, fee5bp/sisi, slip1bp/sisi, funding3bp notional/hari kedua arah. XAU spreadCSV, slip$0.05/oz/sisi, fee$0.03/oz/sisi, swap$1/oz/roll (Rabu3×); EUR spread0.00001, slip0.00001/sisi, fee0.00003/unit/sisi, tanpa swap dalam harness. Tarif broker belum diverifikasi.','- **Stress biaya/delay/leverage portofolio gabungan belum dijalankan.** ACK2s/broker2s adalah asumsi baseline. Stress BTC standalone sebelumnya bukan stress portofolio gabungan. DD≤56% tidak diklaim pada kondisi biaya/delay lain.','- Replay source memakai cached signal kausal, adapter PrepareBasket/ProcessQueue/ManagePositions dan BTC Enter bersama gate host. Full lifecycle native selama8tahun belum direplay. Perubahan native history warmup hanya diuji fixture; tidak menjadi klaim full binary parity.','- Input EUR dalam paket lama terpotong; dipulihkan dari raw ZIP2016–2026 dan prefix asli2011–2015. Hasil tepat sama dengan SHA manifest. Lihat INPUT_RECOVERY.json. Percobaan lokal yang dihentikan/bermasalah tidak dipakai sebagai hasil final.','', '## Sumber dan reproduksi','', 'Source commit: `441088c90d323c008af7016a3adabe24138fd183` pada branch `research/xau-eur-btc-integrated-2019-2026`. Build tools Actions: https://github.com/rizanrizan93/Forex-scanner/actions/runs/39345246182 . Workflow publikasi/audit akhir ditautkan pada jawaban pengiriman.','', 'SHA inputBTC: `c217e367a22cab5f157d6d8a38828b9ada249f5a2d0657f20d204fee881c9504`; XAU: `3fda8011082e2691b6ebe1a8a4da5fff8e4bf0fc07baf57506b7894d95fc1808`; EUR: `3c74ac5ccaeeac64f44693bc6bd4406e9225a9ef61dbb5f80756530f050506ec`. Input penuh tidak digandakan dalam paket; gunakan arsip input yang checksum-nya cocok.','', 'Build: `python build_native.py --sdk /path/to/sdk`; vendor cTrader.Automate1.0.21 dan net6ref6.0.36 ditempatkan seperti script. Compile replay: `python run_local.py /path/to/sdk replay`. Run: `BTC_INPUT=/path/BTCUSD_M1.csv dotnet replay/Replay.dll /path/xau.csv /path/eur.csv /path/results.json matrix 2019 2026`. Skenario0=A,1=B,2=kontrol. ReplayDebug.cs hanya menambah heartbeat, tidak mengubah strategi; source penuh dan diff disertakan.','', 'Grafik memakai snapshotperjam; DD tabel memakai observasi model selama seluruh event aktif. ANNUAL.csv memakai saldo kronologis; MONTHLY.csv mengalokasikan net basket pada bulanclose sehingga dapat berbeda dari perubahan cashbulanan akibat biaya posisi terbuka. Hasil historis hasil optimasi bukan bukti performa masa depan.']
(out/'LAPORAN_XAU_EUR_BTC_2019_2026.md').write_text('\n'.join(report)+'\n')
# Fresh manifest after all package members are final.
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.json'}
(out/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2))
package=root/'RIZAN_XAU_EUR_BTC_INTEGRATED_AUDIT_2019_2026.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in out.rglob('*'):
  if p.is_file():z.write(p,str(p.relative_to(out)))
(root/'PACKAGE_SHA256.txt').write_text(hashlib.sha256(package.read_bytes()).hexdigest()+'  '+package.name+'\n')
print(json.dumps({'metrics':metrics,'package_bytes':package.stat().st_size,'package_sha256':hashlib.sha256(package.read_bytes()).hexdigest()},indent=2))
