"""Install only the new compression service and additive WSS route; never restart old cBots/bridge."""
from pathlib import Path
import os,re,json,sys,shlex,sqlite3,subprocess,shutil,time,socket
UNIT='rizan-compression-bridge.service';OLD='rizan-cbot-bridge.service';TARGET=Path('/opt/rizan-compression-bridge');ENV=Path('/etc/rizan-compression-bridge.env');STATE=Path('/var/lib/rizan-compression-bridge')
def run(args,**kw):return subprocess.run(args,check=True,text=True,capture_output=True,**kw)
def prop(name):return run(['systemctl','show',OLD,'--value','-p',name]).stdout.strip()
def envparse(text):
 result={}
 for line in text.splitlines():
  if line.strip() and not line.lstrip().startswith('#') and '=' in line:
   k,v=line.split('=',1);parts=shlex.split(v.strip());result[k.strip()]=parts[0] if len(parts)==1 else v.strip()
 return result
def inherited():
 out={}
 for setting in shlex.split(prop('Environment')):
  if '=' in setting:k,v=setting.split('=',1);out[k]=v
 for p in re.findall(r'(\S+) \(ignore_errors=(?:yes|no)\)',prop('EnvironmentFiles')):out.update(envparse(Path(p).read_text()))
 return out
def mask_config(text):
 out=list(text);quote=None;comment=False;escaped=False
 for i,c in enumerate(text):
  if comment:
   if c=='\n':comment=False
   else:out[i]=' '
  elif quote:
   out[i]=' '
   if escaped:escaped=False
   elif c=='\\':escaped=True
   elif c==quote:quote=None
  elif c=='#':comment=True;out[i]=' '
  elif c in "\"'":quote=c;out[i]=' '
 return ''.join(out)
def tls_server_close(text):
 masked=mask_config(text);matches=[]
 for m in re.finditer(r'\bserver\s*\{',masked):
  start=m.end()-1;depth=1;i=start+1
  while i<len(masked) and depth:
   depth+=(masked[i]=='{')-(masked[i]=='}');i+=1
  if depth:raise RuntimeError('NGINX_UNBALANCED_CONFIG')
  if re.search(r'\blisten\s+[^;]*\b25345\b',masked[start:i]):matches.append(i-1)
 if len(matches)>1:raise RuntimeError('NGINX_MULTIPLE_25345_SERVERS')
 return matches[0] if matches else None
def main():
 if os.geteuid()!=0:raise RuntimeError('ROOT_REQUIRED')
 source=Path(__file__).resolve().parents[1];oldstart=prop('ExecMainStartTimestampMonotonic');oldstate=prop('ActiveState')
 if ENV.exists() or TARGET.exists() or Path('/etc/systemd/system/'+UNIT).exists():raise RuntimeError('ISOLATED_INSTALL_ALREADY_EXISTS_PRESERVE_STATE')
 old=inherited();token=old.get('RIZAN_BRIDGE_TOKEN','')
 if len(token)<32:raise RuntimeError('EXISTING_BRIDGE_TOKEN_UNAVAILABLE')
 database=Path(old.get('RIZAN_STATE_DB','state/rizan-checkpoints.sqlite'))
 if not database.is_absolute():database=Path(prop('WorkingDirectory'))/database
 with sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True) as db:keys=[r[0] for r in db.execute('SELECT key FROM checkpoints')]
 accounts={k.split(':')[1] for k in keys if len(k.split(':'))==3 and k.split(':')[0] in {'RZXRC1','RZEF245'} and k.split(':')[1].isdigit() and k.split(':')[1].endswith('7903')}
 if len(accounts)!=1:raise RuntimeError('CURRENT_7903_ACCOUNT_NOT_UNIQUE')
 account=next(iter(accounts))
 with socket.socket() as s:s.bind(('127.0.0.1',25348))
 nginx=run(['nginx','-T']).stdout;paths={Path(p).resolve() for p in re.findall(r'^# configuration file ([^:]+):$',nginx,re.M)};candidates=[]
 for p in paths:
  if not p.is_file():continue
  content=p.read_text();end=tls_server_close(content)
  if end is not None:candidates.append((p,content,end))
 if len(candidates)!=1:raise RuntimeError('NGINX_25345_SERVER_NOT_UNIQUE')
 conf,original,end=candidates[0];snippet=Path('/etc/nginx/snippets/rizan-compression-locations.conf')
 if '/compression' in original or snippet.exists():raise RuntimeError('COMPRESSION_ROUTE_ALREADY_PRESENT_REVIEW_REQUIRED')
 run(['python3','-c','import sys; assert sys.version_info >= (3,11)'])
 run(['groupadd','--system','rizan-compression']);run(['useradd','--system','--gid','rizan-compression','--home-dir',str(STATE),'--shell','/usr/sbin/nologin','rizan-compression'])
 TARGET.mkdir(mode=0o755)
 for p in source.iterdir():
  if p.is_file() and (p.suffix=='.py' or p.name in {'requirements.txt','BTC_SEED_PACKET.json'}):shutil.copyfile(p,TARGET/p.name)
 run(['python3','-m','venv',str(TARGET/'.venv')]);run([str(TARGET/'.venv/bin/pip'),'install','--disable-pip-version-check','-r',str(TARGET/'requirements.txt')])
 with ENV.open('x') as f:f.write('R3_HOST=127.0.0.1\nR3_PORT=25348\nR3_STATE_DIR='+str(STATE)+'\nR3_BTC_SEED='+str(TARGET/'BTC_SEED_PACKET.json')+'\nR3_ALLOWED_ACCOUNTS='+account+'\nR3_BRIDGE_TOKEN='+token+'\n')
 ENV.chmod(0o600);shutil.copyfile(source/'deploy'/UNIT,Path('/etc/systemd/system')/UNIT)
 run(['systemctl','daemon-reload']);run(['systemctl','enable','--now',UNIT]);run(['systemctl','is-active','--quiet',UNIT])
 backup=Path('/var/backups/rizan-compression')/str(int(time.time()));backup.mkdir(parents=True,mode=0o700);shutil.copyfile(conf,backup/'nginx-original.conf')
 if conf.read_text()!=original:raise RuntimeError('NGINX_CHANGED_DURING_DEPLOY_REVIEW_REQUIRED')
 snippet.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/'deploy/nginx-r3-locations.conf',snippet)
 try:
  conf.write_text(original[:end]+'\n    include '+str(snippet)+';\n'+original[end:]);run(['nginx','-t']);run(['systemctl','reload','nginx'])
 except Exception:
  conf.write_text(original);snippet.unlink(missing_ok=True);run(['systemctl','stop',UNIT]);raise
 if prop('ActiveState')!=oldstate or prop('ExecMainStartTimestampMonotonic')!=oldstart:raise RuntimeError('EXISTING_BRIDGE_STATE_CHANGED')
 env=os.environ.copy();env.update(envparse(ENV.read_text()),R3_PUBLIC_URL='wss://rizan-bridge.duckdns.org:25345/compression',R3_PROBE_ACCOUNT=account)
 # Authentication/heartbeat must succeed; external data may require a separate warmup.
 for attempt in range(12):
  probe=subprocess.run([str(TARGET/'.venv/bin/python'),str(TARGET/'probe.py')],env=env,text=True,capture_output=True)
  if probe.returncode==0:break
  time.sleep(10)
 report={'deployed':True,'service':UNIT,'old_bridge_not_restarted':True,'account_suffix':'7903','public_wss':'wss://rizan-bridge.duckdns.org:25345/compression/','probe_pass':probe.returncode==0,'probe_output':probe.stdout[-5000:],'token_printed':False,'broker_orders':0}
 print(json.dumps(report,indent=2));Path('/var/lib/rizan-compression-bridge/deployment-verification.json').write_text(json.dumps(report,indent=2))
 if probe.returncode:raise RuntimeError('ISOLATED_BRIDGE_DEPLOYED_BUT_FEED_OR_PUBLIC_PROBE_NOT_READY')
if __name__=='__main__':
 try:main()
 except Exception as e:print('COMPRESSION_DEPLOY_FAILED:'+type(e).__name__+':'+(str(e) if isinstance(e,RuntimeError) else 'see_private_server_diagnostics'));sys.exit(1)
