# Bridge kompresi native31 Oktober2026

Layanan baru `rizan-tp500-bridge` telah dipasang dan diuji melalui WSS publik. Detail dan bukti terkini paket ini ada di `../VPS_VERIFICATION.json` dan `../START_HERE_ID.md`. Source dan profil ini berbeda dari kompresi historis30 Oktober yang belum pulih.

- Backend privat127.0.0.1:25349, env `/etc/rizan-tp500-bridge.env`, database baru `/var/lib/rizan-tp500-bridge/`.
- URL XAU/EUR `wss://rizan-bridge.duckdns.org:25345/tp500/` dan BTC `wss://rizan-bridge.duckdns.org:25345/tp500/btc`.
- Token diwarisi privat dari bridge VPS lama. Token tidak ada di paket ini; satu token utama di cBot cukup, token BTC boleh kosong.
- Prefix CPX/CPE/CPB serta key CPBTC memakai hash profil baru. Checkpoint R3/legacy ditolak. Bridge tidak memiliki API order atau kredensial broker.
- Heartbeat, lease, durable ACK/CAS dan batas timestamp dipertahankan. Data BTC wajib contig dan tepat melalui awal jam terbaru. Sumber gagal tidak diganti feed palsu.
- Installer disertakan untuk reproduksi; jangan menjalankannya ulang pada instalasi yang sudah ada. `provision_isolated.py` tidak me-restart service bridge lama dan hanya menambahkan location Nginx versi kompresi.
- `probe.py` memeriksa auth/heartbeat/data tanpa save checkpoint atau order. Diagnostic lease habis45 detik setelah putus; tunggu60 detik bila menjalankannya sendiri.

Tes: `python -m unittest discover -s . -p 'test_*.py' -v` dari folder bridge dalam bundle lengkap. Fixture C# berada di folder validation saudara. Provenance dasar server tersimpan di PROVENANCE.json; checksum file versi baru ada dalam manifest paket induk.
