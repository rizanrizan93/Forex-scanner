using cAlgo.API;
namespace cAlgo.Robots;
[Robot(TimeZone=TimeZones.UTC,AccessRights=AccessRights.None)]
public sealed class RizanPortfolioTP500Frozen:Rizan.Portfolio.RizanPortfolio {}
