from pathlib import Path
import json,csv,gzip,hashlib,zipfile,io,os,shutil
from datetime import datetime,timedelta
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path(__file__).resolve().parent;out=r/'delivery';out.mkdir(exist_ok=True);prior=r.parent/'btc_macro_event'
def write(p,b):
 if isinstance(b,str):b=b.encode()
 tmp=p.with_name(p.name+'.writing')
 with tmp.open('wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert tmp.read_bytes()==b;os.replace(tmp,p);assert p.read_bytes()==b
base=[json.loads(gzip.decompress((prior/f'delivery/BASE_PATH_{p}_RAW.json.gz').read_bytes())) for p in ['A','B']]
new=[]
for i in [0,1]:new+=json.loads((r/f'replay/shard{i}.json').read_text())['Reports']
assert len(new)==4 and len({x['Summary']['cfg']['Name'] for x in new})==4
reports=base+sorted(new,key=lambda x:(0 if x['Summary']['cfg']['Name'].startswith('RISK') else 1,x['Summary']['cfg']['Name']))
metrics=[];annual=[];monthly=[];directions=[];annual_dirs=[];fills=[];audits=[]
for x in reports:
 s=x['Summary'];name=s['cfg']['Name'];h=x['BrokerHistory'];btc=[a for a in h if a['SymbolName']=='BTCUSD']
 assert not x['CashFlows'] and not x['Open'] and not x['Errors'] and not s['Quarantined'] and not s['AccountingBlock'] and s['TerminalForcedCloses']==0
 for a in h:assert abs(a['NetProfit']-sum(a[k] for k in ['GrossProfit','Commissions','ExitCommission','Swap']))<1e-7
 residual=100+sum(a['NetProfit'] for a in h)-s['EndingBalance'];assert abs(residual)<1e-5,(name,residual)
 peak=100;dd=0
 for a in x['CashEvents']:peak=max(peak,a['Balance']);dd=max(dd,(peak-a['Balance'])/peak)
 assert abs(dd*100-s['MaxClosedDDPct'])<1e-8
 for a in btc:
  e=datetime.fromisoformat(a['EntryTime'].replace('Z','+00:00'));c=datetime.fromisoformat(a['ClosingTime'].replace('Z','+00:00'));assert e.weekday()<5
  cutoff=(e+timedelta(days=(4-e.weekday())%7)).replace(hour=21,minute=30,second=5,microsecond=0);assert c<=cutoff
 gain=sum(max(0,a['Pnl']) for a in x['Ledger']);loss=-sum(min(0,a['Pnl']) for a in x['Ledger']);assert abs(gain/loss-s['PF'])<1e-8
 row=dict(case=name,balance=s['EndingBalance'],floating_dd_pct=s['MaxEquityDDPct'],balance_dd_pct=s['MaxClosedDDPct'],pf=s['PF'],win_rate_pct=100*sum(a['Pnl']>0 for a in x['Ledger'])/s['Baskets'],baskets=s['Baskets'],btc_baskets=s['BtcBaskets'],btc_buy=s['BtcBuys'],btc_sell=s['BtcSells'],btc_net_pnl=sum(a['NetProfit'] for a in btc),btc_buy_net=sum(a['NetProfit'] for a in btc if a['TradeType']==0),btc_sell_net=sum(a['NetProfit'] for a in btc if a['TradeType']==1),cash_residual=residual,errors=s['ErrorCount'])
 metrics.append(row);annual.extend(dict(case=name,**a) for a in x['Annual']);monthly.extend(dict(case=name,**a) for a in x['Monthly']);fills.extend(dict(case=name,**a) for a in h)
 for symbol in ['XAUUSD','EURUSD','BTCUSD']:
  for side in [0,1]:
   v=[a for a in h if a['SymbolName']==symbol and a['TradeType']==side]
   directions.append(dict(case=name,symbol=symbol,side='BUY' if side==0 else 'SELL',fills=len(v),gross_pnl=sum(a['GrossProfit'] for a in v),winning_net_pnl=sum(max(0,a['NetProfit']) for a in v),losing_net_pnl=sum(min(0,a['NetProfit']) for a in v),commission=sum(a['Commissions']+a['ExitCommission'] for a in v),financing=sum(a['Swap'] for a in v),net_pnl=sum(a['NetProfit'] for a in v)))
  for year in range(2019,2027):
   v=[a for a in h if a['SymbolName']==symbol and a['ClosingTime'].startswith(str(year))]
   annual_dirs.append(dict(case=name,year=year,symbol=symbol,net_closed_pnl=sum(a['NetProfit'] for a in v),buy_net=sum(a['NetProfit'] for a in v if a['TradeType']==0),sell_net=sum(a['NetProfit'] for a in v if a['TradeType']==1)))
 audits.append(dict(case=name,cash_residual=residual,balance_dd_recomputed=dd*100,btc_positions=len(btc),weekend_violations=0,baseline_reused=name.startswith('BASE')))
 write(out/f'{name}_RAW.json.gz',gzip.compress(json.dumps(x,separators=(',',':')).encode(),mtime=0))
for name,rows in [('METRICS.csv',metrics),('ANNUAL.csv',annual),('MONTHLY.csv',monthly),('DIRECTION_CONTRIBUTIONS.csv',directions),('ANNUAL_DIRECTION_CONTRIBUTIONS.csv',annual_dirs),('FILL_LEDGER.csv',fills)]:
 buf=io.StringIO();w=csv.DictWriter(buf,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);write(out/name,buf.getvalue())
manifest=json.loads((r.parent/'portfolio_weekend/delivery_v121/FREEZE_MANIFEST.json').read_text());source={}
for n,want in manifest['source_sha256'].items():
 if n.startswith('source/'):
  got=hashlib.sha256((r/n).read_bytes()).hexdigest();assert got==want,n;source[n]=got
body=(r/'replay/Replay.cs').read_text().split('record struct Row',1)[1];old=(prior/'replay/Replay.cs').read_text().split('record struct Row',1)[1];assert body==old
write(out/'AUDIT.json',json.dumps(dict(cases=audits,frozen_source_sha256=source,simulation_body_sha256=hashlib.sha256(body.encode()).hexdigest(),native_source_changed=False,live_changed=False,macro_vintage_certified=False,new_replays=4,reused_controls=2,gate_tests=json.loads((r/'replay/GATE_TEST_RESULTS.json').read_text())),indent=2))
fig,axes=plt.subplots(2,1,figsize=(11,7),sharex=True)
for x in reports:
 name=x['Summary']['cfg']['Name']
 if not name.endswith('_A'):continue
 c=x['Curve'];at=[datetime.fromisoformat(a['At'].replace('Z','+00:00')) for a in c]
 axes[0].plot(at,[a['Equity'] for a in c],label=name.split('_')[0],linewidth=1)
 axes[1].plot(at,[100*(a['Peak']-a['Equity'])/a['Peak'] for a in c],linewidth=.8)
axes[0].set_yscale('log');axes[0].set_ylabel('Equity USD (log)');axes[0].legend();axes[0].set_title('BTC Nasdaq/VIX/2Y veto — shared XAU/EUR/BTC portfolio, Path A');axes[1].set_ylabel('Equity DD % (hourly)');axes[1].axhline(56,color='red',linestyle='--');fig.tight_layout();fig.savefig(out/'EQUITY_DD.png',dpi=150);plt.close(fig)
bases={m['case'][-1]:m for m in metrics if m['case'].startswith('BASE')}
lines=['# Hasil replay BTC dengan makro risk appetite — 20 Oktober 2026','','Empat replay baru selesai, dua kontrol BASE A/B digunakan kembali dari hasil terverifikasi. Modal $100 tanpa top-up; periode 2019–9 Oktober 2026. Saldo/margin/compounding dan peluang entry XAU–EUR–BTC dihitung bersama. Tidak menjumlahkan ulang PnL hasil klasifikasi transaksi lama.','','| Varian | Saldo akhir | Floating DD | Balance DD | PF | BTC BUY/SELL | Net BTC |','|---|---:|---:|---:|---:|---:|---:|']
for m in metrics:lines.append(f"| {m['case']} | ${m['balance']:,.2f} | {m['floating_dd_pct']:.3f}% | {m['balance_dd_pct']:.3f}% | {m['pf']:.3f} | {m['btc_buy']}/{m['btc_sell']} | ${m['btc_net_pnl']:,.2f} |")
lines+=['','## Perubahan terhadap kontrol','','| Varian | Saldo A | Saldo B | Perubahan floating DD A/B (poin persentase) |','|---|---:|---:|---:|']
for mode in ['RISK','TRIPLE']:
 pair={m['case'][-1]:m for m in metrics if m['case'].startswith(mode+'_')}
 lines.append(f"| {mode} | {100*(pair['A']['balance']/bases['A']['balance']-1):+.2f}% | {100*(pair['B']['balance']/bases['B']['balance']-1):+.2f}% | {pair['A']['floating_dd_pct']-bases['A']['floating_dd_pct']:+.3f} / {pair['B']['floating_dd_pct']-bases['B']['floating_dd_pct']:+.3f} |")
lines+=['','Kesimpulan: RISK menurunkan saldo pada kedua path. TRIPLE meningkatkan saldo Path A, tetapi menurunkannya pada Path B; floating DD TRIPLE sedikit lebih tinggi dari kontrol pada keduanya. Tidak ada varian yang memenuhi DD56%. Belum ada bukti peningkatan profit yang konsisten di kedua lintasan; pertahankan baseline dan jangan memasang challenger ke live dari hasil ini.','']
lines+=['','## Konfigurasi terkunci','','RISK: tolak entry hanya jika side × perubahan Nasdaq10020observasi <0 DAN side × perubahan VIX5observasi >0. TRIPLE: kedua kondisi itu ditambah side × perubahan yield AS2tahun20observasi >0. side=+1 BUY dan−1 SELL. Ini filter veto, tidak membalik arah atau menciptakan entry baru, tidak menutup posisi berjalan, dan tidak mengubah TP/SL, sizing, sesi atau aturan weekend. Tidak menambahkan trigger M5/M15 sweep/BOS/retest. Data lag konservatif2hari kerja federal AS; batas stale10hari.','','BTC tetap leverage model10×, XAU/EUR200×; risk cap portfolio20,75%, margin entry50%, biaya dasar dan delay2detik sama dengan frozen. Satu basket BTC, tanpa layeringBTC. Jumat blockentry60menit sebelumclose dan flat30menit sebelumclose; replay memakai asumsi Jumat22UTC. Native tetap memakai MarketHours.','','## Audit dan batas kesimpulan','','Seluruh cash direkonsiliasi dari gross PnL, komisi, financing dan net PnL; balance DD dan PF dihitung ulang secara independen; tidak ada posisi terbuka akhir, error runtime, quarantine atau pelanggaran weekend. Source strategi14file dan badan simulator identik dengan versi sebelumnya.433pemeriksaan filter mencakup107sinyal, parityPython/C#, input tidak dikenal, mismatchcoverage, serta larangan informasi masa depan menurut asumsi waktu ketersediaan.','','Data macro historical current-vintage belum sertifikasi ALFRED/point-in-time. Lag bukan bukti bebas revisi. Konteks macroXAU rekonstruksi lama tetap belum tersertifikasi. Dua pathOHLC diagnostik bukan tickbroker, bukan FULL_PARITY atau batas konservatif semua lintasanM1. Semua periode pernah digunakan untuk pemilihan strategiBTC, sehingga bukan out-of-sample murni. Belum stressbiaya/delay untuk dua challengerbaru. DXY, ETFflow, likuiditasmingguan, CPI/NFP surprise dan reactionentry belum ditambahkan. Tidak mengubah cBotaktif atau bridge. Jangan menyimpulkan filter ini amanlive atau profitmasa depan hanya dari tabel ini.','','Files: METRICS.csv, ANNUAL.csv, MONTHLY.csv, DIRECTION_CONTRIBUTIONS.csv, ANNUAL_DIRECTION_CONTRIBUTIONS.csv, FILL_LEDGER.csv, AUDIT.json, source, adapter, dan rawenamcases.']
write(out/'LAPORAN_REPLAY_BTC_MACRO_RISK.md','\n'.join(lines)+'\n')
for name in ['REPLAY_PROTOCOL.json','check_inputs.py','run_local.py','build_gate_tests.py','finalize_replay.py','verify_replay_zip.py']:
 if (r/name).is_file():shutil.copy2(r/name,out/name)
for folder in ['source','tests','data']:shutil.copytree(r/folder,out/folder,dirs_exist_ok=True,ignore=shutil.ignore_patterns('risk_daily.csv'))
(out/'adapter').mkdir(exist_ok=True)
for name in ['Replay.cs','BtcMacroGate.cs','GateTests.cs','ApiStubs.cs','GATE_TEST_RESULTS.json']:shutil.copy2(r/'replay'/name,out/'adapter'/name)
shutil.copy2(r/'output/SIGNAL_MACRO_FEATURES.csv',out/'SIGNAL_MACRO_FEATURES.csv')
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file() and p.name!='SHA256_MANIFEST.json'};write(out/'SHA256_MANIFEST.json',json.dumps(manifest,indent=2))
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in out.rglob('*'):
  if p.is_file():z.write(p,str(p.relative_to(out)))
pack=r/'RIZAN_BTC_MACRO_RISK_REPLAY_20261020.zip';write(pack,buf.getvalue());b=pack.read_bytes()
write(r/'PACKAGE_META.json',json.dumps(dict(size=len(b),sha256=hashlib.sha256(b).hexdigest(),git_blob_sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()),indent=2));print(json.dumps(metrics,indent=2));print((r/'PACKAGE_META.json').read_text())
