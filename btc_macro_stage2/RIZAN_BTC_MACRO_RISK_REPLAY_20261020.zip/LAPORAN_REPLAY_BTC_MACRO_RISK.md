# Hasil replay BTC dengan makro risk appetite — 20 Oktober 2026

Empat replay baru selesai, dua kontrol BASE A/B digunakan kembali dari hasil terverifikasi. Modal $100 tanpa top-up; periode 2019–9 Oktober 2026. Saldo/margin/compounding dan peluang entry XAU–EUR–BTC dihitung bersama. Tidak menjumlahkan ulang PnL hasil klasifikasi transaksi lama.

| Varian | Saldo akhir | Floating DD | Balance DD | PF | BTC BUY/SELL | Net BTC |
|---|---:|---:|---:|---:|---:|---:|
| BASE_PATH_A | $14,168,707.28 | 62.949% | 49.624% | 2.447 | 41/55 | $580,360.40 |
| BASE_PATH_B | $18,043,274.23 | 63.777% | 51.610% | 2.399 | 40/55 | $1,372,484.86 |
| RISK_PATH_A | $13,078,898.02 | 59.625% | 51.327% | 2.395 | 40/40 | $383,353.87 |
| RISK_PATH_B | $15,954,430.36 | 67.180% | 60.343% | 2.391 | 39/40 | $567,344.67 |
| TRIPLE_PATH_A | $15,002,332.76 | 63.776% | 49.623% | 2.504 | 39/49 | $864,491.39 |
| TRIPLE_PATH_B | $17,104,201.45 | 63.827% | 50.298% | 2.408 | 41/49 | $951,986.41 |

## Perubahan terhadap kontrol

| Varian | Saldo A | Saldo B | Perubahan floating DD A/B (poin persentase) |
|---|---:|---:|---:|
| RISK | -7.69% | -11.58% | -3.324 / +3.403 |
| TRIPLE | +5.88% | -5.20% | +0.827 / +0.051 |

Kesimpulan: RISK menurunkan saldo pada kedua path. TRIPLE meningkatkan saldo Path A, tetapi menurunkannya pada Path B; floating DD TRIPLE sedikit lebih tinggi dari kontrol pada keduanya. Tidak ada varian yang memenuhi DD56%. Belum ada bukti peningkatan profit yang konsisten di kedua lintasan; pertahankan baseline dan jangan memasang challenger ke live dari hasil ini.


## Konfigurasi terkunci

RISK: tolak entry hanya jika side × perubahan Nasdaq10020observasi <0 DAN side × perubahan VIX5observasi >0. TRIPLE: kedua kondisi itu ditambah side × perubahan yield AS2tahun20observasi >0. side=+1 BUY dan−1 SELL. Ini filter veto, tidak membalik arah atau menciptakan entry baru, tidak menutup posisi berjalan, dan tidak mengubah TP/SL, sizing, sesi atau aturan weekend. Tidak menambahkan trigger M5/M15 sweep/BOS/retest. Data lag konservatif2hari kerja federal AS; batas stale10hari.

BTC tetap leverage model10×, XAU/EUR200×; risk cap portfolio20,75%, margin entry50%, biaya dasar dan delay2detik sama dengan frozen. Satu basket BTC, tanpa layeringBTC. Jumat blockentry60menit sebelumclose dan flat30menit sebelumclose; replay memakai asumsi Jumat22UTC. Native tetap memakai MarketHours.

## Audit dan batas kesimpulan

Seluruh cash direkonsiliasi dari gross PnL, komisi, financing dan net PnL; balance DD dan PF dihitung ulang secara independen; tidak ada posisi terbuka akhir, error runtime, quarantine atau pelanggaran weekend. Source strategi14file dan badan simulator identik dengan versi sebelumnya.433pemeriksaan filter mencakup107sinyal, parityPython/C#, input tidak dikenal, mismatchcoverage, serta larangan informasi masa depan menurut asumsi waktu ketersediaan.

Data macro historical current-vintage belum sertifikasi ALFRED/point-in-time. Lag bukan bukti bebas revisi. Konteks macroXAU rekonstruksi lama tetap belum tersertifikasi. Dua pathOHLC diagnostik bukan tickbroker, bukan FULL_PARITY atau batas konservatif semua lintasanM1. Semua periode pernah digunakan untuk pemilihan strategiBTC, sehingga bukan out-of-sample murni. Belum stressbiaya/delay untuk dua challengerbaru. DXY, ETFflow, likuiditasmingguan, CPI/NFP surprise dan reactionentry belum ditambahkan. Tidak mengubah cBotaktif atau bridge. Jangan menyimpulkan filter ini amanlive atau profitmasa depan hanya dari tabel ini.

Files: METRICS.csv, ANNUAL.csv, MONTHLY.csv, DIRECTION_CONTRIBUTIONS.csv, ANNUAL_DIRECTION_CONTRIBUTIONS.csv, FILL_LEDGER.csv, AUDIT.json, source, adapter, dan rawenamcases.
